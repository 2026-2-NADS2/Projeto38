﻿// AlunoController: classe principal de orquestração do sistema.
// Integra a camada de acesso a dados (AlunoDB) com as requisições HTTP,
// garantindo o fluxo adequado das operações de CRUD sobre os alunos.

using Microsoft.AspNetCore.Mvc;
using PIEstruturaDeDados.Data;
using PIEstruturaDeDados.Models;

namespace PIpoo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlunoController : ControllerBase
    {
        private readonly AlunoDB _repositorio;

        public AlunoController(AlunoDB repositorio)
        {
            _repositorio = repositorio;
        }

        [HttpGet]
        public ActionResult<List<Aluno>> ObterTodos()
        {
            return Ok(_repositorio.ObterTodos());
        }

        [HttpGet("{id}")]
        public ActionResult<Aluno> ObterPorId(int id)
        {
            var aluno = _repositorio.ObterPorId(id);
            if (aluno == null) return NotFound();
            return Ok(aluno);
        }

        [HttpPost]
        public ActionResult Criar(Aluno aluno)
        {
            _repositorio.Inserir(aluno);
            return CreatedAtAction(nameof(ObterPorId), new { id = aluno.Id }, aluno);
        }

        [HttpPut("{id}")]
        public ActionResult Atualizar(int id, Aluno aluno)
        {
            aluno.Id = id;
            _repositorio.Atualizar(aluno);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult Excluir(int id)
        {
            _repositorio.Excluir(id);
            return NoContent();
        }
    }
}