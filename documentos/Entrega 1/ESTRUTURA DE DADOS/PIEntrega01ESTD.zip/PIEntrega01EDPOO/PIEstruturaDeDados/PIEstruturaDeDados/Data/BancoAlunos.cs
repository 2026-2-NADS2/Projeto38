﻿using Microsoft.Data.Sqlite;
using PIEstruturaDeDados.Models;
using System.Drawing;
//using System;
//using System.Collections.Generic;
using System.Globalization;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

namespace PIEstruturaDeDados.Data
{
    internal class AlunoDB
    {
        private readonly string _connectionString;
        public AlunoDB(string caminhoBanco)
        {
            _connectionString = $"Data Source={caminhoBanco}";
            CriarTabelaSeNaoExistir();
        }

        // Tabela criada automaticamente no construtor, garantindo que o banco
        // sempre esteja pronto para uso assim que a classe for instanciada.
        private void CriarTabelaSeNaoExistir()
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                CREATE TABLE IF NOT EXISTS Aluno (
                    Id  INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                    Nome  TEXT not null, 
                    Turma TEXT not null,  
                    Media REAL not null
                );
            ";
            comando.ExecuteNonQuery();
        }

        // Uso de parâmetros nomeados (@Nome, @Turma, @Media) para evitar SQL Injection,
        // conforme requisito de segurança do projeto.
        public void Inserir(Aluno item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
        INSERT INTO Aluno (Nome, Turma, Media)
        VALUES (@Nome, @Turma, @Media);
    ";
            comando.Parameters.AddWithValue("@Nome", item.Nome);
            comando.Parameters.AddWithValue("@Turma", item.Turma);
            comando.Parameters.AddWithValue("@Media", item.Media);

            comando.ExecuteNonQuery();
        }

        public List<Aluno> ObterTodos()
        {
            var lista = new List<Aluno>();

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Id, Nome, Turma, Media
                  FROM Aluno
              ORDER BY Id;
            ";


            Double Media;
            string Turma;
            string Nome;
            int Id;
            Aluno alun;
            using var reader = comando.ExecuteReader();
            while (reader.Read())
            {
                Id = reader.GetInt32(0);
                Nome = reader.GetString(1);
                Turma = reader.GetString(2);
                Media = reader.GetDouble(3);
                alun = new Aluno(Id, Nome, Turma, Media);
        
                lista.Add(alun);
            }

            return lista;
        }

        public void Atualizar(Aluno item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));

            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
        UPDATE Aluno
           SET Nome = @Nome,
            Turma = @Turma,
            Media = @Media
         WHERE Id  = @Id;
    ";
            comando.Parameters.AddWithValue("@Id", item.Id);
            comando.Parameters.AddWithValue("@Nome", item.Nome);
            comando.Parameters.AddWithValue("@Turma", item.Turma);
            comando.Parameters.AddWithValue("@Media", item.Media);

            comando.ExecuteNonQuery();
        }

        public void Excluir(int Id)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                DELETE FROM Aluno
                 WHERE Id = @Id;
            ";
            comando.Parameters.AddWithValue("@Id", Id);

            comando.ExecuteNonQuery();
        }

        public Aluno? ObterPorId(int Id)
        {
            using var conexao = new SqliteConnection(_connectionString);
            conexao.Open();

            using var comando = conexao.CreateCommand();
            comando.CommandText = @"
                SELECT Id, Nome, Turma, Media
                  FROM Aluno
                 WHERE Id = @Id;
            ";
            comando.Parameters.AddWithValue("@Id", Id);

            using var reader = comando.ExecuteReader();

            if (reader.Read())
            
            {
                  int id = reader.GetInt32(0);
                  string  Nome = reader.GetString(1);
                  string  Turma = reader.GetString(2);
                  double  Media = reader.GetDouble(3);
                  return new Aluno(id, Nome, Turma, Media);
                                   
            }

            return null;
        }
    }
}