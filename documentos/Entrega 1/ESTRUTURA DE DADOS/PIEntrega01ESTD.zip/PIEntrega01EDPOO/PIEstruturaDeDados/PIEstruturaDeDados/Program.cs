﻿using PIEstruturaDeDados.Data;
using PIEstruturaDeDados.Models;


Console.OutputEncoding = System.Text.Encoding.UTF8;

string caminhoBanco = @"alunos.db";

// Classe orquestradora: integra o acesso ao banco (AlunoDB) com a
// exibição paginada dos dados, representando o fluxo central do sistema.
var repositorio = new AlunoDB(caminhoBanco);
List<Aluno> alunos = repositorio.ObterTodos();

if (alunos.Count == 0)
{
    repositorio.Inserir(new Aluno(0, "Ana", "6ºA", 8.5));
    repositorio.Inserir(new Aluno(0, "Bruno", "6ºB", 7.2));
    repositorio.Inserir(new Aluno(0, "Carla", "7ºA", 9.1));
    repositorio.Inserir(new Aluno(0, "Diego", "7ºB", 6.8));
    repositorio.Inserir(new Aluno(0, "Elisa", "8ºA", 7.9));
    repositorio.Inserir(new Aluno(0, "Felipe ", "6ºA", 8.0));
    repositorio.Inserir(new Aluno(0, "Gabriela", "6ºB", 7.5));
    repositorio.Inserir(new Aluno(0, "Hugo ", "7ºA", 9.3));
    repositorio.Inserir(new Aluno(0, "Isabela ", "7ºB", 6.5));
    repositorio.Inserir(new Aluno(0, "João ", "8ºA", 8.8));
    repositorio.Inserir(new Aluno(0, "Karina ", "6ºA", 7.0));
    repositorio.Inserir(new Aluno(0, "Lucas ", "6ºB", 8.2));
    repositorio.Inserir(new Aluno(0, "Marina ", "7ºA", 9.0));
    repositorio.Inserir(new Aluno(0, "Nicolas ", "7ºB", 6.9));
    repositorio.Inserir(new Aluno(0, "Olivia ", "8ºA", 7.7));

    alunos = repositorio.ObterTodos(); 
}

Console.WriteLine("=== Sistema de Listagem de Alunos ===");

void imprimirPagina(List<Aluno> lista, int inicio, int fim)
{
    Console.Clear();
    Console.WriteLine("========================================");
    Console.WriteLine("     SISTEMA DE LISTAGEM DE ALUNOS");
    Console.WriteLine("========================================");
    Console.WriteLine($"{"Nome",-20} {"Turma",-8} {"Média",-6}");
    Console.WriteLine("----------------------------------------");

    for (int i = inicio; i < fim && i < lista.Count; i++)
    {
        Console.WriteLine($"{lista[i].Nome,-20} {lista[i].Turma,-8} {lista[i].Media,-6}");
    }

    Console.WriteLine("========================================");
}

int pageSize = 4;
int totalPaginas = (int)Math.Ceiling(alunos.Count / (double)pageSize);
int paginaAtual = 1;
int opcao = 1;

while (opcao != 5)
{
    int inicio = (paginaAtual - 1) * pageSize;
    int fim = inicio + pageSize;

    imprimirPagina(alunos, inicio, fim);
    Console.WriteLine($"Página {paginaAtual} de {totalPaginas}");

    Console.WriteLine("1 - Próxima página");
    Console.WriteLine("2 - Página anterior");
    Console.WriteLine("3 - Primeira página");
    Console.WriteLine("4 - Última página");
    Console.WriteLine("5 - Sair");
    Console.Write("\nEscolha uma opção: ");

    if (!int.TryParse(Console.ReadLine(), out opcao))
    {
        Console.WriteLine("Opção inválida. Pressione uma tecla para tentar novamente...");
        Console.ReadKey();
        continue;
    }

    switch (opcao)
    {
        case 1:
            if (paginaAtual < totalPaginas) paginaAtual++;
            break;
        case 2:
            if (paginaAtual > 1) paginaAtual--;
            break;
        case 3:
            paginaAtual = 1;
            break;
        case 4:
            paginaAtual = totalPaginas;
            break;
    }
}
Console.WriteLine("\nEncerrando o sistema. Até logo!");