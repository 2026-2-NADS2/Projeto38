﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIEstruturaDeDados.Models
{
    internal class Aluno
    {
        // Encapsulamento: propriedades com get/set em vez de campos públicos diretos,
        // permitindo futura validação sem quebrar quem já usa a classe. 
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Turma { get; set; }
        public double Media { get; set; }

        public Aluno() 
        {
        }

        public Aluno(int id, string nome, string turma, double media)
        {
            if (media < 0 || media > 10)
                throw new ArgumentException("Média deve estar entre 0 e 10.");

            Id = id;
            Nome = nome;
            Turma = turma;
            Media = media;
        }

        public override string ToString()
        {
            return $"[{Id}] {Nome} - Turma: {Turma} - Média: {Media}";
        }
    }
}
