// vite.config.mjs — front-end React (pasta client/).
//   npm run dev:web  -> servidor de desenvolvimento em http://localhost:5173
//                       (as chamadas /api vão para o Express em http://localhost:3000)
//   npm run build    -> gera client/dist, que o Express entrega em produção
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  root: 'client',
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:3000',
    },
  },
});
