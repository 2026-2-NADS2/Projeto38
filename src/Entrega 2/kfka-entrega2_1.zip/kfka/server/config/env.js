// env.js — lê e valida as variáveis de ambiente em um único lugar.
// Nenhuma credencial fica escrita no código: tudo vem do arquivo .env
// (local) ou das "Environment Variables" do serviço de hospedagem.

require('dotenv').config();

const NODE_ENV = process.env.NODE_ENV || 'development';

const env = {
  NODE_ENV,
  isProducao: NODE_ENV === 'production',
  PORT: Number(process.env.PORT) || 3000,
  // mysql://usuario:senha@host:3306/kfka
  DATABASE_URL: process.env.DATABASE_URL,
  DATABASE_SSL: process.env.DATABASE_SSL === 'true',
  // Fuso usado pelo MySQL (NOW() dos triggers) e na leitura das datas.
  // Brasília = -03:00 (sem horário de verão desde 2019).
  DB_TIMEZONE: process.env.DB_TIMEZONE || '-03:00',
  JWT_SECRET: process.env.JWT_SECRET,
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '8h',
  ANO_LETIVO: Number(process.env.ANO_LETIVO) || new Date().getFullYear(),
  CORS_ORIGIN: (process.env.CORS_ORIGIN || '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean),
  SEED_SENHA: process.env.SEED_SENHA,
};

// Falha logo na inicialização se algo essencial estiver faltando —
// é melhor do que descobrir o erro só quando alguém tentar fazer login.
const obrigatorias = ['DATABASE_URL', 'JWT_SECRET'];
const faltando = obrigatorias.filter((nome) => !env[nome]);

if (faltando.length) {
  console.error(
    `\n[KFKA] Variáveis de ambiente obrigatórias não definidas: ${faltando.join(', ')}\n` +
      '        Copie .env.example para .env e preencha os valores.\n'
  );
  process.exit(1);
}

if (!/^mysql:\/\//.test(env.DATABASE_URL)) {
  console.error('[KFKA] DATABASE_URL deve começar com mysql://  (ex.: mysql://root:senha@localhost:3306/kfka)');
  process.exit(1);
}

if (!/^[+-]\d{2}:\d{2}$/.test(env.DB_TIMEZONE)) {
  console.error('[KFKA] DB_TIMEZONE deve estar no formato +HH:MM ou -HH:MM (ex.: -03:00).');
  process.exit(1);
}

if (env.isProducao && env.JWT_SECRET.length < 32) {
  console.error('[KFKA] Em produção, JWT_SECRET deve ter pelo menos 32 caracteres.');
  process.exit(1);
}

module.exports = env;
