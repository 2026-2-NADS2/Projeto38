// index.js — ponto de entrada: confere o banco e inicia o servidor.
//
// O banco NÃO é criado automaticamente (o script da equipe faz DROP DATABASE).
// Na primeira vez, rode:  npm run db:setup

const env = require('./config/env');
const app = require('./app');
const db = require('./db');
const { explicarErroBanco } = require('./db/explicarErro');

async function conferirBanco() {
  try {
    await db.query('SELECT COUNT(*) AS n FROM usuario');
  } catch (err) {
    if (err.errno === 1146 || err.errno === 1049) {
      console.error('\n[KFKA] O banco "kfka" ainda não foi criado. Rode:  npm run db:setup\n');
    } else {
      console.error('\n[KFKA] Não foi possível conectar ao MySQL:', explicarErroBanco(err));
      console.error('        Confira DATABASE_URL no .env e se o MySQL está rodando.\n');
    }
    process.exit(1);
  }

  const [pendentes] = await db.query("SELECT COUNT(*) AS n FROM usuario WHERE senha_hash LIKE '$2a$10$TROCAR%'");
  if (Number(pendentes.n) > 0) {
    console.warn(`[KFKA] ${pendentes.n} usuário(s) de demonstração ainda sem senha. Rode:  npm run db:senhas`);
  }
}

async function iniciar() {
  await conferirBanco();

  const servidor = app.listen(env.PORT, () => {
    console.log(`[KFKA] Servidor rodando em http://localhost:${env.PORT} (${env.NODE_ENV})`);
  });

  // Encerramento limpo (Render/Railway/Docker enviam SIGTERM ao reiniciar)
  const encerrar = () => {
    servidor.close(() => db.pool.end().then(() => process.exit(0)));
  };
  process.on('SIGTERM', encerrar);
  process.on('SIGINT', encerrar);
}

iniciar();
