// auth.js — autenticação (JWT) e autorização por perfil.

const jwt = require('jsonwebtoken');
const env = require('../config/env');
const AppError = require('../utils/AppError');

// No banco o perfil é 'ADMIN' | 'PROFESSOR' | 'RESPONSAVEL'; na API usamos minúsculas.
const perfilApi = (perfilBanco) => String(perfilBanco).toLowerCase();

// O token guarda também o id de professor/responsável (diferente do id de usuário),
// para as rotas não precisarem consultar isso a cada requisição.
function gerarToken(usuario) {
  return jwt.sign(
    {
      sub: usuario.id,
      nome: usuario.nome,
      perfil: perfilApi(usuario.perfil),
      pid: usuario.professor_id ?? null,
      rid: usuario.responsavel_id ?? null,
    },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }
  );
}

// Exige o cabeçalho  Authorization: Bearer <token>
function autenticar(req, res, next) {
  const [tipo, token] = (req.headers.authorization || '').split(' ');

  if (tipo !== 'Bearer' || !token) {
    return next(AppError.naoAutenticado());
  }

  try {
    const dados = jwt.verify(token, env.JWT_SECRET);
    req.usuario = {
      id: Number(dados.sub),
      nome: dados.nome,
      perfil: dados.perfil,
      professorId: dados.pid ?? null,
      responsavelId: dados.rid ?? null,
    };
    return next();
  } catch (err) {
    const msg =
      err.name === 'TokenExpiredError'
        ? 'Sua sessão expirou. Faça login novamente.'
        : 'Token inválido. Faça login novamente.';
    return next(AppError.naoAutenticado(msg));
  }
}

// Uso: autorizar('admin', 'professor')
function autorizar(...perfisPermitidos) {
  return (req, res, next) => {
    if (!req.usuario || !perfisPermitidos.includes(req.usuario.perfil)) {
      return next(AppError.semPermissao());
    }
    return next();
  };
}

module.exports = { gerarToken, autenticar, autorizar, perfilApi };
