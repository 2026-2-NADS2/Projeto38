// explicarErro.js — transforma erros de conexão do MySQL em mensagens claras.
// (No Node 20+, "conexão recusada" chega como AggregateError com a mensagem vazia.)

function explicarErroBanco(err) {
  const codigo = err.code || err.errors?.[0]?.code || '';
  const detalhe = err.message || err.errors?.map((e) => e.message).join('; ') || codigo || String(err);
  const dicas = {
    ECONNREFUSED: 'O MySQL recusou a conexão: confira se o endereço/porta do DATABASE_URL no .env estão certos (com o Railway, use a MYSQL_PUBLIC_URL) e se o .env foi salvo.',
    ENOTFOUND: 'Endereço do banco não encontrado: confira o host no DATABASE_URL do .env.',
    ETIMEDOUT: 'O banco não respondeu a tempo: confira host/porta no DATABASE_URL e sua conexão com a internet.',
    ER_ACCESS_DENIED_ERROR: 'Usuário ou senha do MySQL incorretos no DATABASE_URL.',
    ER_BAD_DB_ERROR: 'O banco "kfka" ainda não existe. Rode: npm run db:setup',
    HANDSHAKE_SSL_ERROR: 'O provedor exige SSL: coloque DATABASE_SSL=true no .env.',
  };
  return `${detalhe}${codigo && !detalhe.includes(codigo) ? ` (${codigo})` : ''}${dicas[codigo] ? `\n        → ${dicas[codigo]}` : ''}`;
}

module.exports = { explicarErroBanco };
