// db/setup.js — instala o banco a partir do script da equipe (database/kfka_banco.sql).
//
//   npm run db:setup     -> APAGA e recria o banco "kfka" (tabelas, triggers, views e dados)
//                           e grava a senha real dos usuários de demonstração
//   npm run db:senhas    -> só grava a senha dos usuários de demonstração
//
// A senha vem de SEED_SENHA no .env (ex.: Senha@123). O script SQL traz um
// marcador no lugar do hash bcrypt; este comando substitui pelo hash verdadeiro.
//
// Por que não rodar o .sql direto pelo Node? O comando DELIMITER (usado nos
// triggers) é do cliente MySQL (Workbench/terminal), não do servidor. Aqui o
// arquivo é dividido em comandos respeitando o DELIMITER, e cada um é enviado.
// Rodar o script pelo Workbench também funciona — depois use npm run db:senhas.

const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const env = require('../config/env');
const { explicarErroBanco } = require('./explicarErro');

const ARQUIVO_SQL = path.join(__dirname, '..', '..', 'database', 'kfka_banco.sql');
const MARCADOR_SENHA = '$2a$10$TROCAR%';

// Remove comentário "-- ..." do fim da linha, ignorando "--" dentro de textos entre aspas
function removerComentario(linha) {
  let aspas = null;
  for (let i = 0; i < linha.length; i++) {
    const c = linha[i];
    if (aspas) {
      if (c === aspas) aspas = null;
      continue;
    }
    if (c === "'" || c === '"') aspas = c;
    else if (c === '-' && linha[i + 1] === '-' && (i + 2 >= linha.length || /\s/.test(linha[i + 2]))) {
      return linha.slice(0, i);
    }
  }
  return linha;
}

// Divide o script em comandos, respeitando "DELIMITER $$" ... "DELIMITER ;"
function dividirScript(texto) {
  const comandos = [];
  let delimitador = ';';
  let atual = [];

  for (const original of texto.split(/\r?\n/)) {
    const linha = removerComentario(original);
    const t = linha.trim();
    if (!t) continue;

    const troca = t.match(/^DELIMITER\s+(\S+)$/i);
    if (troca) {
      delimitador = troca[1];
      continue;
    }

    atual.push(linha);
    if (t.endsWith(delimitador)) {
      const comando = atual.join('\n').trim().slice(0, -delimitador.length).trim();
      if (comando) comandos.push(comando);
      atual = [];
    }
  }
  const resto = atual.join('\n').trim();
  if (resto) comandos.push(resto);
  return comandos;
}

async function executarScript() {
  const comandos = dividirScript(fs.readFileSync(ARQUIVO_SQL, 'utf8'));
  // Conecta SEM escolher banco: o próprio script faz DROP/CREATE/USE kfka
  const url = new URL(env.DATABASE_URL);
  const conexao = await mysql.createConnection({
    host: url.hostname,
    port: Number(url.port) || 3306,
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    ssl: env.DATABASE_SSL ? { rejectUnauthorized: false } : undefined,
    timezone: env.DB_TIMEZONE,
  });
  try {
    await conexao.query(`SET time_zone = '${env.DB_TIMEZONE}'`);
    for (const [i, comando] of comandos.entries()) {
      try {
        await conexao.query(comando);
      } catch (err) {
        err.message = `Comando ${i + 1} de ${comandos.length} falhou: ${err.message}\n---\n${comando.slice(0, 300)}`;
        throw err;
      }
    }
  } finally {
    await conexao.end();
  }
  return comandos.length;
}

async function definirSenhasDemo() {
  if (!env.SEED_SENHA) {
    console.warn('[KFKA] SEED_SENHA não definida no .env — senhas de demonstração não foram gravadas.');
    return 0;
  }
  const db = require('./index');
  const hash = await bcrypt.hash(env.SEED_SENHA, 10);
  const r = await db.query('UPDATE usuario SET senha_hash = ? WHERE senha_hash LIKE ?', [hash, MARCADOR_SENHA]);
  return r.affectedRows;
}

async function prepararBanco({ somenteSenhas = false } = {}) {
  const comandos = somenteSenhas ? 0 : await executarScript();
  const senhas = await definirSenhasDemo();
  return { comandos, senhas };
}

module.exports = { prepararBanco, dividirScript };

// Executado pelo terminal (npm run db:setup / db:senhas)
if (require.main === module) {
  const somenteSenhas = process.argv.includes('--somente-senhas');

  if (!somenteSenhas && env.isProducao && !process.argv.includes('--forcar')) {
    console.error('[KFKA] db:setup APAGA o banco. Em produção, rode: node server/db/setup.js --forcar');
    process.exit(1);
  }

  prepararBanco({ somenteSenhas })
    .then(({ comandos, senhas }) => {
      if (comandos) console.log(`[KFKA] Script executado (${comandos} comandos).`);
      console.log(`[KFKA] Senha de demonstração gravada em ${senhas} usuário(s).`);
      return require('./index').pool.end();
    })
    .catch((err) => {
      console.error('[KFKA] Falha ao preparar o banco:', explicarErroBanco(err));
      // Mostra para onde tentou conectar (sem a senha), para facilitar a conferência
      try {
        const u = new URL(env.DATABASE_URL);
        console.error(`        Tentou conectar em: ${u.hostname}:${u.port || 3306} (usuário ${u.username})`);
      } catch {
        /* URL inválida: já foi avisado */
      }
      process.exit(1);
    });
}
