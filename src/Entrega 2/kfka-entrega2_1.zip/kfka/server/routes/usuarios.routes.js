// usuarios.routes.js
//
//   GET  /api/usuarios            (admin)   lista usuários (filtro opcional ?perfil=)
//   POST /api/usuarios            (admin)   cria professor, admin ou responsável
//   GET  /api/usuarios/contatos   (logado)  pessoas com quem o usuário pode conversar

const { Router } = require('express');
const bcrypt = require('bcryptjs');

const db = require('../db');
const schemas = require('../schemas');
const validar = require('../middlewares/validar');
const { autenticar, autorizar, perfilApi } = require('../middlewares/auth');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const router = Router();
router.use(autenticar);

router.get(
  '/',
  autorizar('admin'),
  asyncHandler(async (req, res) => {
    const perfil = ['admin', 'professor', 'responsavel'].includes(req.query.perfil)
      ? req.query.perfil.toUpperCase()
      : null;
    const linhas = await db.query(
      `SELECT u.id, u.nome, u.email, u.perfil, u.ativo, u.ultimo_login_em, u.criado_em,
              p.registro, COALESCE(p.telefone, r.telefone) AS telefone
         FROM usuario u
         LEFT JOIN professor   p ON p.usuario_id = u.id
         LEFT JOIN responsavel r ON r.usuario_id = u.id
        WHERE (? IS NULL OR u.perfil = ?)
        ORDER BY u.nome`,
      [perfil, perfil]
    );
    res.json({ dados: linhas.map((u) => ({ ...u, perfil: perfilApi(u.perfil), ativo: Boolean(u.ativo) })) });
  })
);

router.post(
  '/',
  autorizar('admin'),
  validar(schemas.novoUsuario),
  asyncHandler(async (req, res) => {
    const { nome, email, senha, perfil, registro, telefone } = req.body;

    const existe = await db.query('SELECT id FROM usuario WHERE email = ?', [email]);
    if (existe.length) throw AppError.conflito('Este e-mail já está cadastrado.');

    const senhaHash = await bcrypt.hash(senha, 10);
    const id = await db.transacao(req.usuario.id, async (tx) => {
      const u = await tx.query('INSERT INTO usuario (nome, email, senha_hash, perfil) VALUES (?, ?, ?, ?)', [
        nome,
        email,
        senhaHash,
        perfil.toUpperCase(),
      ]);
      if (perfil === 'professor') {
        await tx.query('INSERT INTO professor (usuario_id, registro, telefone) VALUES (?, ?, ?)', [
          u.insertId,
          registro,
          telefone,
        ]);
      } else if (perfil === 'responsavel') {
        await tx.query('INSERT INTO responsavel (usuario_id, telefone) VALUES (?, ?)', [u.insertId, telefone]);
      }
      return u.insertId;
    });

    res.status(201).json({ dados: { id, nome, email, perfil } });
  })
);

// Responsáveis só conversam com a equipe da escola; a equipe conversa com todos.
router.get(
  '/contatos',
  asyncHandler(async (req, res) => {
    const somenteEquipe = req.usuario.perfil === 'responsavel' ? 1 : 0;
    const linhas = await db.query(
      `SELECT id, nome, perfil
         FROM usuario
        WHERE id <> ? AND ativo = TRUE
          AND (? = 0 OR perfil IN ('ADMIN', 'PROFESSOR'))
        ORDER BY perfil, nome`,
      [req.usuario.id, somenteEquipe]
    );
    res.json({ dados: linhas.map((u) => ({ ...u, perfil: perfilApi(u.perfil) })) });
  })
);

module.exports = router;
