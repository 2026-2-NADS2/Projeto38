// acompanhamentos.routes.js — lançamento bimestral e fluxo editorial.
//
// Fluxo de status (validado pelo trigger trg_acomp_bu no banco):
//   RASCUNHO -> ENVIADO -> EM_REVISAO -> PUBLICADO
//                  \____________\-------> DEVOLVIDO -> ENVIADO ...
//   PUBLICADO -> EM_REVISAO (retificação)
//
//   GET   /api/acompanhamentos?turma_id&disciplina_id&bimestre_id  (professor, admin)  planilha da turma
//   PUT   /api/acompanhamentos                                     (professor)  salva rascunho ou envia
//   POST  /api/acompanhamentos/:id/enviar                          (professor)  rascunho/devolvido -> enviado
//   GET   /api/acompanhamentos/fila?status=pendentes|devolvidos|publicados|rascunhos
//   PATCH /api/acompanhamentos/:id/publicar                        (admin)
//   PATCH /api/acompanhamentos/:id/devolver   { motivo }           (admin)
//   PATCH /api/acompanhamentos/:id/retificar  { motivo }           (admin)  publicado -> em revisão
//   GET   /api/acompanhamentos/:id/historico                       (admin, professor do registro)
//   POST  /api/acompanhamentos/:id/ciencia    { observacao? }      (responsável)
//
// Toda gravação passa por db.transacao(), que define @usuario_id para a auditoria.

const { Router } = require('express');

const db = require('../db');
const schemas = require('../schemas');
const validar = require('../middlewares/validar');
const { autenticar, autorizar, perfilApi } = require('../middlewares/auth');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const router = Router();
router.use(autenticar);

const status = (s) => (s ? String(s).toLowerCase() : null);

// Último motivo de devolução de cada registro (vem do histórico/auditoria)
async function motivosDevolucao(ids) {
  if (!ids.length) return {};
  const linhas = await db.query(
    `SELECT acompanhamento_id, observacao FROM historico_acompanhamento
      WHERE acompanhamento_id IN (?) AND acao = 'MUDANCA_STATUS' AND status_novo = 'DEVOLVIDO'
      ORDER BY data_hora, id`,
    [ids]
  );
  return Object.fromEntries(linhas.map((l) => [l.acompanhamento_id, l.observacao]));
}

async function tagsDe(ids) {
  if (!ids.length) return {};
  const linhas = await db.query(
    `SELECT at2.acompanhamento_id, t.id, t.nome
       FROM acompanhamento_tag at2 JOIN tag t ON t.id = at2.tag_id
      WHERE at2.acompanhamento_id IN (?) ORDER BY t.nome`,
    [ids]
  );
  const mapa = {};
  for (const l of linhas) (mapa[l.acompanhamento_id] ||= []).push({ id: l.id, nome: l.nome });
  return mapa;
}

async function professorLeciona(professorId, turmaId, disciplinaId) {
  const r = await db.query(
    'SELECT turma_id FROM turma_disciplina_professor WHERE turma_id = ? AND disciplina_id = ? AND professor_id = ?',
    [turmaId, disciplinaId, professorId]
  );
  return r.length > 0;
}

// ---------------------------------------------------------------------------
// Planilha de lançamento: todos os alunos da turma + o registro de cada um
// ---------------------------------------------------------------------------
router.get(
  '/',
  autorizar('professor', 'admin'),
  validar(schemas.filtroLancamentos, 'query'),
  asyncHandler(async (req, res) => {
    const { turma_id, disciplina_id, bimestre_id } = req.validado.query;

    if (req.usuario.perfil === 'professor' && !(await professorLeciona(req.usuario.professorId, turma_id, disciplina_id))) {
      throw AppError.semPermissao('Você não leciona esta disciplina nesta turma.');
    }

    const [bimestre] = await db.query(
      `SELECT id, ano_letivo, numero, digitacao_inicio, digitacao_fim,
              (NOW() BETWEEN digitacao_inicio AND digitacao_fim) AS aberto
         FROM bimestre WHERE id = ?`,
      [bimestre_id]
    );
    if (!bimestre) throw AppError.naoEncontrado('Bimestre não encontrado.');

    const linhas = await db.query(
      `SELECT a.id AS aluno_id, a.nome, a.matricula,
              ac.id, ac.media, ac.faltas, ac.descricao, ac.status, ac.versao, ac.atualizado_em
         FROM turma_aluno ta
         JOIN aluno a ON a.id = ta.aluno_id
         LEFT JOIN acompanhamento ac
                ON ac.aluno_id = a.id AND ac.disciplina_id = ? AND ac.bimestre_id = ?
        WHERE ta.turma_id = ? AND a.ativo = TRUE
        ORDER BY a.nome`,
      [disciplina_id, bimestre_id, turma_id]
    );

    const ids = linhas.filter((l) => l.id).map((l) => l.id);
    const [tags, motivos] = await Promise.all([tagsDe(ids), motivosDevolucao(ids)]);

    res.json({
      dados: {
        bimestre: { ...bimestre, aberto: Boolean(bimestre.aberto) },
        alunos: linhas.map((l) => ({
          aluno_id: l.aluno_id,
          nome: l.nome,
          matricula: l.matricula,
          acompanhamento: l.id
            ? {
                id: l.id,
                media: l.media,
                faltas: l.faltas,
                descricao: l.descricao,
                status: status(l.status),
                versao: l.versao,
                atualizado_em: l.atualizado_em,
                tags: tags[l.id] || [],
                motivo_devolucao: l.status === 'DEVOLVIDO' ? motivos[l.id] || null : null,
              }
            : null,
        })),
      },
    });
  })
);

// ---------------------------------------------------------------------------
// Salvar (rascunho) ou salvar e enviar para revisão
// ---------------------------------------------------------------------------
router.put(
  '/',
  autorizar('professor'),
  validar(schemas.lancamento),
  asyncHandler(async (req, res) => {
    const { aluno_id, disciplina_id, bimestre_id, media, faltas, descricao, tags, enviar } = req.body;
    const professorId = req.usuario.professorId;

    const resultado = await db.transacao(req.usuario.id, async (tx) => {
      const [bimestre] = await tx.query('SELECT id, ano_letivo FROM bimestre WHERE id = ?', [bimestre_id]);
      if (!bimestre) throw AppError.naoEncontrado('Bimestre não encontrado.');

      // A turma do aluno no ano do bimestre (a FK composta exige que ele esteja matriculado)
      const [matricula] = await tx.query(
        `SELECT ta.turma_id FROM turma_aluno ta JOIN aluno a ON a.id = ta.aluno_id
          WHERE ta.aluno_id = ? AND ta.ano_letivo = ? AND a.ativo = TRUE`,
        [aluno_id, bimestre.ano_letivo]
      );
      if (!matricula) throw AppError.naoEncontrado('Aluno não matriculado em nenhuma turma neste ano.');

      const vinculo = await tx.query(
        'SELECT turma_id FROM turma_disciplina_professor WHERE turma_id = ? AND disciplina_id = ? AND professor_id = ?',
        [matricula.turma_id, disciplina_id, professorId]
      );
      if (!vinculo.length) throw AppError.semPermissao('Você não leciona esta disciplina na turma do aluno.');

      const [atual] = await tx.query(
        'SELECT id, status FROM acompanhamento WHERE aluno_id = ? AND disciplina_id = ? AND bimestre_id = ? FOR UPDATE',
        [aluno_id, disciplina_id, bimestre_id]
      );

      let id;
      let criado = false;
      if (!atual) {
        // O trigger trg_acomp_bi confere o período de digitação e grava a CRIACAO no histórico
        const r = await tx.query(
          `INSERT INTO acompanhamento
             (aluno_id, turma_id, disciplina_id, professor_id, bimestre_id, descricao, media, faltas, status)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [aluno_id, matricula.turma_id, disciplina_id, professorId, bimestre_id, descricao, media, faltas, enviar ? 'ENVIADO' : 'RASCUNHO']
        );
        id = r.insertId;
        criado = true;
      } else {
        if (!['RASCUNHO', 'DEVOLVIDO'].includes(atual.status)) {
          throw AppError.conflito(
            `Este registro está "${status(atual.status).replace('_', ' ')}" e não pode mais ser editado pelo professor.`
          );
        }
        // O trigger trg_acomp_bu valida período e transição e grava a EDICAO no histórico
        await tx.query('UPDATE acompanhamento SET media = ?, faltas = ?, descricao = ?, status = ? WHERE id = ?', [
          media,
          faltas,
          descricao,
          enviar ? 'ENVIADO' : atual.status,
          atual.id,
        ]);
        id = atual.id;
      }

      await tx.query('DELETE FROM acompanhamento_tag WHERE acompanhamento_id = ?', [id]);
      for (const tagId of tags) {
        await tx.query('INSERT INTO acompanhamento_tag (acompanhamento_id, tag_id) VALUES (?, ?)', [id, tagId]);
      }

      const [salvo] = await tx.query(
        'SELECT id, media, faltas, descricao, status, versao, atualizado_em FROM acompanhamento WHERE id = ?',
        [id]
      );
      return { criado, salvo };
    });

    const { criado, salvo } = resultado;
    const tagsSalvas = (await tagsDe([salvo.id]))[salvo.id] || [];
    res.status(criado ? 201 : 200).json({ dados: { ...salvo, status: status(salvo.status), tags: tagsSalvas } });
  })
);

router.post(
  '/:id/enviar',
  autorizar('professor'),
  validar(schemas.paramId, 'params'),
  asyncHandler(async (req, res) => {
    const id = req.validado.params.id;
    const salvo = await db.transacao(req.usuario.id, async (tx) => {
      const [atual] = await tx.query('SELECT id, status, professor_id FROM acompanhamento WHERE id = ? FOR UPDATE', [id]);
      if (!atual || atual.professor_id !== req.usuario.professorId) throw AppError.naoEncontrado('Registro não encontrado.');
      if (!['RASCUNHO', 'DEVOLVIDO'].includes(atual.status)) {
        throw AppError.conflito('Só é possível enviar registros em rascunho ou devolvidos.');
      }
      await tx.query("UPDATE acompanhamento SET status = 'ENVIADO' WHERE id = ?", [id]);
      return (await tx.query('SELECT id, status, enviado_em FROM acompanhamento WHERE id = ?', [id]))[0];
    });
    res.json({ dados: { ...salvo, status: status(salvo.status) } });
  })
);

// ---------------------------------------------------------------------------
// Fila de revisão (usa a view vw_acompanhamento_completo do banco)
// ---------------------------------------------------------------------------
const FILAS = {
  pendentes: ['ENVIADO', 'EM_REVISAO'],
  devolvidos: ['DEVOLVIDO'],
  publicados: ['PUBLICADO'],
  rascunhos: ['RASCUNHO'],
};

router.get(
  '/fila',
  autorizar('admin', 'professor'),
  validar(schemas.filtroFila, 'query'),
  asyncHandler(async (req, res) => {
    const filtro = req.validado.query.status;
    const doProfessor = req.usuario.perfil === 'professor';
    const linhas = await db.query(
      `SELECT v.acompanhamento_id AS id, v.ano_letivo, v.bimestre, v.turma, v.aluno_id, v.aluno, v.disciplina,
              v.professor_id, v.professor, v.media, v.faltas, v.descricao, v.status, v.versao, v.tags,
              v.revisor, v.enviado_em, v.publicado_em
         FROM vw_acompanhamento_completo v
        WHERE v.status IN (?) AND (? IS NULL OR v.professor_id = ?)
        ORDER BY v.enviado_em, v.acompanhamento_id`,
      [FILAS[filtro], doProfessor ? req.usuario.professorId : null, doProfessor ? req.usuario.professorId : null]
    );

    const motivos = filtro === 'devolvidos' ? await motivosDevolucao(linhas.map((l) => l.id)) : {};
    const agora = Date.now();
    res.json({
      dados: linhas.map((l) => ({
        ...l,
        status: status(l.status),
        tags: l.tags ? l.tags.split(', ') : [],
        motivo_devolucao: motivos[l.id] || null,
        horas_aguardando:
          FILAS.pendentes.includes(l.status) && l.enviado_em
            ? Math.max(0, Math.floor((agora - new Date(l.enviado_em).getTime()) / 3600000))
            : null,
      })),
      meta: { total: linhas.length },
    });
  })
);

// Lê o registro travado (FOR UPDATE) para mudar o status com segurança
async function travar(tx, id) {
  const [atual] = await tx.query('SELECT id, status FROM acompanhamento WHERE id = ? FOR UPDATE', [id]);
  if (!atual) throw AppError.naoEncontrado('Registro não encontrado.');
  return atual;
}

async function estadoFinal(tx, id) {
  const [r] = await tx.query(
    'SELECT id, status, versao, publicado_em, revisor_id FROM acompanhamento WHERE id = ?',
    [id]
  );
  return { ...r, status: status(r.status) };
}

router.patch(
  '/:id/publicar',
  autorizar('admin'),
  validar(schemas.paramId, 'params'),
  asyncHandler(async (req, res) => {
    const id = req.validado.params.id;
    const dados = await db.transacao(req.usuario.id, async (tx) => {
      const atual = await travar(tx, id);
      if (!['ENVIADO', 'EM_REVISAO'].includes(atual.status)) {
        throw AppError.conflito(`Só é possível publicar registros enviados ou em revisão (atual: ${status(atual.status)}).`);
      }
      // O banco exige passar por EM_REVISAO antes de PUBLICADO — as duas etapas
      // ficam registradas no histórico, na mesma transação
      if (atual.status === 'ENVIADO') {
        await tx.query("UPDATE acompanhamento SET status = 'EM_REVISAO' WHERE id = ?", [id]);
      }
      await tx.query("UPDATE acompanhamento SET status = 'PUBLICADO' WHERE id = ?", [id]);
      return estadoFinal(tx, id);
    });
    res.json({ dados });
  })
);

router.patch(
  '/:id/devolver',
  autorizar('admin'),
  validar(schemas.paramId, 'params'),
  validar(schemas.devolucao),
  asyncHandler(async (req, res) => {
    const id = req.validado.params.id;
    const dados = await db.transacao(req.usuario.id, async (tx) => {
      const atual = await travar(tx, id);
      if (!['ENVIADO', 'EM_REVISAO'].includes(atual.status)) {
        throw AppError.conflito(`Só é possível devolver registros enviados ou em revisão (atual: ${status(atual.status)}).`);
      }
      await tx.observacao(req.body.motivo); // vai para historico_acompanhamento.observacao
      await tx.query("UPDATE acompanhamento SET status = 'DEVOLVIDO' WHERE id = ?", [id]);
      return estadoFinal(tx, id);
    });
    res.json({ dados: { ...dados, motivo_devolucao: req.body.motivo } });
  })
);

router.patch(
  '/:id/retificar',
  autorizar('admin'),
  validar(schemas.paramId, 'params'),
  validar(schemas.retificacao),
  asyncHandler(async (req, res) => {
    const id = req.validado.params.id;
    const dados = await db.transacao(req.usuario.id, async (tx) => {
      const atual = await travar(tx, id);
      if (atual.status !== 'PUBLICADO') throw AppError.conflito('Só registros publicados podem ser retificados.');
      await tx.observacao(req.body.motivo);
      await tx.query("UPDATE acompanhamento SET status = 'EM_REVISAO' WHERE id = ?", [id]);
      return estadoFinal(tx, id);
    });
    res.json({ dados });
  })
);

// ---------------------------------------------------------------------------
// Histórico (auditoria gravada pelos triggers)
// ---------------------------------------------------------------------------
router.get(
  '/:id/historico',
  autorizar('admin', 'professor'),
  validar(schemas.paramId, 'params'),
  asyncHandler(async (req, res) => {
    const id = req.validado.params.id;
    const [registro] = await db.query(
      `SELECT acompanhamento_id AS id, aluno, disciplina, bimestre, turma, professor_id, status, versao
         FROM vw_acompanhamento_completo WHERE acompanhamento_id = ?`,
      [id]
    );
    if (!registro || (req.usuario.perfil === 'professor' && registro.professor_id !== req.usuario.professorId)) {
      throw AppError.naoEncontrado('Registro não encontrado.');
    }

    const eventos = await db.query(
      `SELECT h.id, h.acao, h.status_anterior, h.status_novo, h.media_anterior, h.media_nova,
              h.faltas_anterior, h.faltas_nova, h.descricao_anterior, h.descricao_nova,
              h.observacao, h.data_hora, u.nome AS usuario, u.perfil
         FROM historico_acompanhamento h
         JOIN usuario u ON u.id = h.usuario_id
        WHERE h.acompanhamento_id = ?
        ORDER BY h.data_hora, h.id`,
      [id]
    );

    res.json({
      dados: {
        registro: { ...registro, status: status(registro.status) },
        eventos: eventos.map((e) => ({
          ...e,
          status_anterior: status(e.status_anterior),
          status_novo: status(e.status_novo),
          perfil: perfilApi(e.perfil),
        })),
      },
    });
  })
);

// ---------------------------------------------------------------------------
// Ciência do responsável (com retorno opcional para a escola)
// ---------------------------------------------------------------------------
router.post(
  '/:id/ciencia',
  autorizar('responsavel'),
  validar(schemas.paramId, 'params'),
  validar(schemas.ciencia),
  asyncHandler(async (req, res) => {
    const id = req.validado.params.id;
    // A view só traz registros PUBLICADOS de alunos vinculados e autorizados
    const [relatorio] = await db.query(
      `SELECT acompanhamento_id, data_ciencia FROM vw_relatorio_responsavel
        WHERE responsavel_id = ? AND acompanhamento_id = ?`,
      [req.usuario.responsavelId, id]
    );
    if (!relatorio) throw AppError.naoEncontrado('Relatório não encontrado ou ainda não publicado.');
    if (relatorio.data_ciencia) throw AppError.conflito('Você já confirmou a ciência deste relatório.');

    await db.query(
      'INSERT INTO ciencia_responsavel (acompanhamento_id, responsavel_id, observacao) VALUES (?, ?, ?)',
      [id, req.usuario.responsavelId, req.body.observacao]
    );
    const [salva] = await db.query(
      'SELECT data_ciencia, observacao FROM ciencia_responsavel WHERE acompanhamento_id = ? AND responsavel_id = ?',
      [id, req.usuario.responsavelId]
    );
    res.status(201).json({ dados: { acompanhamento_id: id, ...salva } });
  })
);

module.exports = router;
