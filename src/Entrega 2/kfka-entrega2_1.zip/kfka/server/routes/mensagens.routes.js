// mensagens.routes.js — módulo Comunicação (tabela mensagem).
//
//   GET  /api/mensagens/conversas    lista de conversas (último texto + não lidas)
//   GET  /api/mensagens/:usuarioId   histórico com um contato (marca como lidas)
//   POST /api/mensagens              envia mensagem { destinatario_id, texto }

const { Router } = require('express');

const db = require('../db');
const schemas = require('../schemas');
const validar = require('../middlewares/validar');
const { autenticar, perfilApi } = require('../middlewares/auth');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const router = Router();
router.use(autenticar);

const formatar = (m, meuId) => ({
  id: m.id,
  remetente_id: m.remetente_id,
  destinatario_id: m.destinatario_id,
  texto: m.texto,
  lida: Boolean(m.lida),
  criado_em: m.criado_em,
  minha: m.remetente_id === meuId,
});

// Regra: responsável não conversa com outro responsável; contas inativas não recebem.
async function buscarContatoPermitido(eu, contatoId) {
  if (contatoId === eu.id) throw AppError.requisicaoInvalida('Você não pode enviar mensagem para si mesmo.');

  const [contato] = await db.query('SELECT id, nome, perfil, ativo FROM usuario WHERE id = ?', [contatoId]);
  if (!contato || !contato.ativo) throw AppError.naoEncontrado('Contato não encontrado.');

  const perfil = perfilApi(contato.perfil);
  if (eu.perfil === 'responsavel' && perfil === 'responsavel') {
    throw AppError.semPermissao('Responsáveis só podem conversar com a equipe da escola.');
  }
  return { id: contato.id, nome: contato.nome, perfil };
}

router.get(
  '/conversas',
  asyncHandler(async (req, res) => {
    const eu = req.usuario.id;
    const mensagens = await db.query(
      `SELECT id, remetente_id, destinatario_id, texto, lida, criado_em
         FROM mensagem
        WHERE remetente_id = ? OR destinatario_id = ?
        ORDER BY criado_em DESC, id DESC
        LIMIT 1000`,
      [eu, eu]
    );

    // Agrupa por contato: a primeira mensagem de cada um (lista já ordenada) é a mais recente
    const conversas = new Map();
    for (const m of mensagens) {
      const contatoId = m.remetente_id === eu ? m.destinatario_id : m.remetente_id;
      if (!conversas.has(contatoId)) {
        conversas.set(contatoId, {
          contato_id: contatoId,
          ultima_mensagem: m.texto,
          ultima_em: m.criado_em,
          enviada_por_mim: m.remetente_id === eu,
          nao_lidas: 0,
        });
      }
      if (m.destinatario_id === eu && !m.lida) conversas.get(contatoId).nao_lidas += 1;
    }
    if (!conversas.size) return res.json({ dados: [] });

    const ids = [...conversas.keys()];
    const usuarios = await db.query('SELECT id, nome, perfil FROM usuario WHERE id IN (?)', [ids]);
    // Para responsáveis, mostra de quem são responsáveis (ex.: "Resp. de Lucas Ribeiro")
    const filhos = await db.query(
      `SELECT r.usuario_id, a.nome
         FROM responsavel r
         JOIN aluno_responsavel ar ON ar.responsavel_id = r.id
         JOIN aluno a ON a.id = ar.aluno_id
        WHERE r.usuario_id IN (?) AND a.ativo = TRUE
        ORDER BY a.nome`,
      [ids]
    );

    const dados = [...conversas.values()].map((c) => {
      const u = usuarios.find((x) => x.id === c.contato_id) || { nome: 'Usuário removido', perfil: '' };
      const alunos = filhos.filter((f) => f.usuario_id === c.contato_id).map((f) => f.nome);
      return { ...c, nome: u.nome, perfil: perfilApi(u.perfil), alunos: alunos.length ? alunos.join(', ') : null };
    });
    res.json({ dados });
  })
);

router.get(
  '/:usuarioId',
  validar(schemas.paramContato, 'params'),
  asyncHandler(async (req, res) => {
    const eu = req.usuario.id;
    const contato = await buscarContatoPermitido(req.usuario, req.validado.params.usuarioId);

    await db.query('UPDATE mensagem SET lida = TRUE WHERE remetente_id = ? AND destinatario_id = ? AND lida = FALSE', [
      contato.id,
      eu,
    ]);

    // As 200 mais recentes, em ordem cronológica
    const recentes = await db.query(
      `SELECT id, remetente_id, destinatario_id, texto, lida, criado_em
         FROM mensagem
        WHERE (remetente_id = ? AND destinatario_id = ?) OR (remetente_id = ? AND destinatario_id = ?)
        ORDER BY criado_em DESC, id DESC
        LIMIT 200`,
      [eu, contato.id, contato.id, eu]
    );
    res.json({ dados: { contato, mensagens: recentes.reverse().map((m) => formatar(m, eu)) } });
  })
);

router.post(
  '/',
  validar(schemas.mensagem),
  asyncHandler(async (req, res) => {
    const eu = req.usuario.id;
    const contato = await buscarContatoPermitido(req.usuario, req.body.destinatario_id);
    const r = await db.query('INSERT INTO mensagem (remetente_id, destinatario_id, texto) VALUES (?, ?, ?)', [
      eu,
      contato.id,
      req.body.texto,
    ]);
    const [m] = await db.query(
      'SELECT id, remetente_id, destinatario_id, texto, lida, criado_em FROM mensagem WHERE id = ?',
      [r.insertId]
    );
    res.status(201).json({ dados: formatar(m, eu) });
  })
);

module.exports = router;
