// boletim.routes.js — relatório do responsável (tela e impressão/PDF).
//
//   GET /api/boletim   (responsável)  filhos vinculados + registros PUBLICADOS, por bimestre e disciplina
//
// Usa a view vw_relatorio_responsavel do banco, que já aplica as regras:
// só registros PUBLICADOS e só de alunos com vínculo autorizado.

const { Router } = require('express');

const db = require('../db');
const env = require('../config/env');
const { autenticar, autorizar } = require('../middlewares/auth');
const asyncHandler = require('../utils/asyncHandler');

const router = Router();
router.use(autenticar, autorizar('responsavel'));

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const rid = req.usuario.responsavelId;

    // Filhos vinculados (aparecem mesmo sem nada publicado ainda)
    const filhos = await db.query(
      `SELECT a.id, a.nome, a.matricula, ar.parentesco, t.nome AS turma
         FROM aluno_responsavel ar
         JOIN aluno a ON a.id = ar.aluno_id
         LEFT JOIN turma_aluno ta ON ta.aluno_id = a.id AND ta.ano_letivo = ?
         LEFT JOIN turma t        ON t.id = ta.turma_id
        WHERE ar.responsavel_id = ? AND ar.autorizado = TRUE AND a.ativo = TRUE
        ORDER BY a.nome`,
      [env.ANO_LETIVO, rid]
    );

    const registros = await db.query(
      `SELECT acompanhamento_id AS id, aluno_id, bimestre, area, disciplina, professor, media, faltas,
              descricao, tags, publicado_em, data_ciencia, retorno_responsavel
         FROM vw_relatorio_responsavel
        WHERE responsavel_id = ? AND ano_letivo = ?
        ORDER BY bimestre, disciplina`,
      [rid, env.ANO_LETIVO]
    );

    const dados = filhos.map((f) => {
      const meus = registros
        .filter((r) => r.aluno_id === f.id)
        .map(({ aluno_id, ...r }) => ({ ...r, tags: r.tags ? r.tags.split(', ') : [] }));

      // Agrupa por bimestre: [{ numero: 1, disciplinas: [...] }, ...]
      const bimestres = [...new Set(meus.map((r) => r.bimestre))].map((numero) => ({
        numero,
        disciplinas: meus.filter((r) => r.bimestre === numero),
      }));

      const medias = meus.map((r) => Number(r.media));
      return {
        ...f,
        resumo: {
          media: medias.length ? Number((medias.reduce((s, n) => s + n, 0) / medias.length).toFixed(2)) : null,
          faltas_total: meus.reduce((s, r) => s + Number(r.faltas), 0),
          aguardando_ciencia: meus.filter((r) => !r.data_ciencia).length,
          publicados: meus.length,
        },
        bimestres,
      };
    });

    res.json({ dados });
  })
);

module.exports = router;
