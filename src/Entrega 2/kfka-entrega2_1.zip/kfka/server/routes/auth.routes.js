// auth.routes.js — cadastro, login e dados do usuário logado.
//
//   POST /api/auth/cadastro   (público)  cria conta de responsável (usuario + responsavel)
//   POST /api/auth/login      (público)  devolve um token JWT
//   GET  /api/auth/me         (logado)   dados do usuário do token

const { Router } = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');

const db = require('../db');
const schemas = require('../schemas');
const validar = require('../middlewares/validar');
const { gerarToken, autenticar, perfilApi } = require('../middlewares/auth');
const AppError = require('../utils/AppError');
const asyncHandler = require('../utils/asyncHandler');

const router = Router();

// Limita tentativas para dificultar ataques de força bruta na senha
const limiteTentativas = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  handler: (req, res) =>
    res.status(429).json({
      erro: {
        codigo: 'MUITAS_TENTATIVAS',
        mensagem: 'Muitas tentativas. Aguarde alguns minutos e tente novamente.',
      },
    }),
});

// Usuário + id de professor/responsável (cada perfil tem sua tabela 1:1 no banco)
const SQL_USUARIO = `
  SELECT u.id, u.nome, u.email, u.perfil, u.ativo, u.senha_hash,
         p.id AS professor_id, r.id AS responsavel_id
    FROM usuario u
    LEFT JOIN professor   p ON p.usuario_id = u.id
    LEFT JOIN responsavel r ON r.usuario_id = u.id`;

const publico = (u) => ({ id: u.id, nome: u.nome, email: u.email, perfil: perfilApi(u.perfil) });

async function senhaConfere(senha, hash) {
  try {
    return await bcrypt.compare(senha, hash);
  } catch {
    return false; // hash malformado
  }
}

// Cadastro público: cria sempre um RESPONSÁVEL, registrando o aceite da LGPD.
// Professores e administradores são criados pela coordenação (POST /api/usuarios).
router.post(
  '/cadastro',
  limiteTentativas,
  validar(schemas.cadastro),
  asyncHandler(async (req, res) => {
    const { nome, email, senha, telefone } = req.body;

    const existe = await db.query('SELECT id FROM usuario WHERE email = ?', [email]);
    if (existe.length) throw AppError.conflito('Este e-mail já está cadastrado.');

    const senhaHash = await bcrypt.hash(senha, 10);
    const usuario = await db.transacao(null, async (tx) => {
      const u = await tx.query(
        "INSERT INTO usuario (nome, email, senha_hash, perfil) VALUES (?, ?, ?, 'RESPONSAVEL')",
        [nome, email, senhaHash]
      );
      const r = await tx.query('INSERT INTO responsavel (usuario_id, telefone, aceite_lgpd_em) VALUES (?, ?, NOW())', [
        u.insertId,
        telefone,
      ]);
      return { id: u.insertId, nome, email, perfil: 'RESPONSAVEL', responsavel_id: r.insertId };
    });

    res.status(201).json({ dados: { token: gerarToken(usuario), usuario: publico(usuario) } });
  })
);

router.post(
  '/login',
  limiteTentativas,
  validar(schemas.login),
  asyncHandler(async (req, res) => {
    const { email, senha } = req.body;
    const [usuario] = await db.query(`${SQL_USUARIO} WHERE u.email = ?`, [email]);

    // Ajuda no primeiro uso: o script SQL vem com um marcador no lugar do hash
    if (usuario && usuario.senha_hash.startsWith('$2a$10$TROCAR')) {
      throw new AppError(
        503,
        'SENHA_DEMO_NAO_CONFIGURADA',
        'As senhas de demonstração ainda não foram geradas. Rode "npm run db:senhas" no servidor.'
      );
    }

    // Mesma mensagem para e-mail inexistente e senha errada (não revela quais e-mails existem)
    if (!usuario || !(await senhaConfere(senha, usuario.senha_hash))) {
      throw AppError.naoAutenticado('E-mail ou senha incorretos.');
    }
    if (!usuario.ativo) {
      throw new AppError(403, 'CONTA_DESATIVADA', 'Sua conta está desativada. Procure a coordenação da escola.');
    }

    await db.query('UPDATE usuario SET ultimo_login_em = NOW() WHERE id = ?', [usuario.id]);
    res.json({ dados: { token: gerarToken(usuario), usuario: publico(usuario) } });
  })
);

router.get(
  '/me',
  autenticar,
  asyncHandler(async (req, res) => {
    const [usuario] = await db.query(`${SQL_USUARIO} WHERE u.id = ?`, [req.usuario.id]);
    if (!usuario || !usuario.ativo) throw AppError.naoAutenticado('Usuário não encontrado. Faça login novamente.');
    res.json({ dados: publico(usuario) });
  })
);

module.exports = router;
