// escola.routes.js — cadastros de apoio da escola.
//
//   GET  /api/turmas                     (logado)  turmas do ano; professor vê só as que leciona
//   POST /api/turmas                     (admin)   cria turma
//   GET  /api/disciplinas?turma_id=      (logado)  disciplinas da turma (professor: só as dele)
//   GET  /api/bimestres?ano_letivo=      (logado)  bimestres e se a digitação está aberta agora
//   GET  /api/tags                       (logado)  tags de desempenho ativas

const { Router } = require('express');

const db = require('../db');
const env = require('../config/env');
const schemas = require('../schemas');
const validar = require('../middlewares/validar');
const { autenticar, autorizar } = require('../middlewares/auth');
const asyncHandler = require('../utils/asyncHandler');

const router = Router();
// Montado em /api: o login é exigido rota a rota (um router.use aqui
// bloquearia também o 404 de rotas inexistentes da API).

const professorDe = (usuario) => (usuario.perfil === 'professor' ? usuario.professorId : null);

router.get(
  '/turmas',
  autenticar,
  asyncHandler(async (req, res) => {
    const professorId = professorDe(req.usuario);
    const linhas = await db.query(
      `SELECT t.id, t.nome, t.serie, t.ano_letivo, t.turno,
              (SELECT COUNT(*) FROM turma_aluno ta JOIN aluno a ON a.id = ta.aluno_id
                WHERE ta.turma_id = t.id AND a.ativo = TRUE) AS total_alunos
         FROM turma t
        WHERE t.ativo = TRUE AND t.ano_letivo = ?
          AND (? IS NULL OR t.id IN (SELECT turma_id FROM turma_disciplina_professor WHERE professor_id = ?))
        ORDER BY t.serie, t.nome`,
      [env.ANO_LETIVO, professorId, professorId]
    );
    res.json({ dados: linhas });
  })
);

router.post(
  '/turmas',
  autenticar,
  autorizar('admin'),
  validar(schemas.turma),
  asyncHandler(async (req, res) => {
    const { nome, serie, ano_letivo, turno } = req.body;
    const r = await db.query('INSERT INTO turma (nome, serie, ano_letivo, turno) VALUES (?, ?, ?, ?)', [
      nome,
      serie,
      ano_letivo,
      turno,
    ]);
    res.status(201).json({ dados: { id: r.insertId, nome, serie, ano_letivo, turno } });
  })
);

router.get(
  '/disciplinas',
  autenticar,
  asyncHandler(async (req, res) => {
    const turmaId = Number(req.query.turma_id) || null;
    const professorId = professorDe(req.usuario);

    // Sem turma: catálogo completo de disciplinas
    if (!turmaId) {
      const linhas = await db.query(
        `SELECT d.id, d.nome, ar.nome AS area
           FROM disciplina d JOIN area ar ON ar.id = d.area_id
          WHERE d.ativo = TRUE ORDER BY d.nome`
      );
      return res.json({ dados: linhas });
    }

    const linhas = await db.query(
      `SELECT d.id, d.nome, ar.nome AS area, up.nome AS professor
         FROM turma_disciplina_professor tdp
         JOIN disciplina d ON d.id = tdp.disciplina_id
         JOIN area ar      ON ar.id = d.area_id
         JOIN professor p  ON p.id = tdp.professor_id
         JOIN usuario up   ON up.id = p.usuario_id
        WHERE tdp.turma_id = ? AND (? IS NULL OR tdp.professor_id = ?)
        ORDER BY d.nome`,
      [turmaId, professorId, professorId]
    );
    return res.json({ dados: linhas });
  })
);

router.get(
  '/bimestres',
  autenticar,
  asyncHandler(async (req, res) => {
    const ano = Number(req.query.ano_letivo) || env.ANO_LETIVO;
    const linhas = await db.query(
      `SELECT id, ano_letivo, numero, digitacao_inicio, digitacao_fim,
              (NOW() BETWEEN digitacao_inicio AND digitacao_fim) AS aberto
         FROM bimestre WHERE ano_letivo = ? ORDER BY numero`,
      [ano]
    );
    res.json({ dados: linhas.map((b) => ({ ...b, aberto: Boolean(b.aberto) })) });
  })
);

router.get(
  '/tags',
  autenticar,
  asyncHandler(async (req, res) => {
    const linhas = await db.query('SELECT id, nome, descricao FROM tag WHERE ativo = TRUE ORDER BY nome');
    res.json({ dados: linhas });
  })
);

module.exports = router;
