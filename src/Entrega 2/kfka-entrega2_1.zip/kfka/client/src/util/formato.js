// formato.js — rótulos e formatação usados em várias telas.

export const ROTULO_PERFIL = { admin: 'Coordenação', professor: 'Professor(a)', responsavel: 'Responsável' };

// Status do fluxo editorial (banco) + situações calculadas (pendente, sem_lancamento)
export const ROTULO_STATUS = {
  rascunho: 'Rascunho',
  enviado: 'Enviado',
  em_revisao: 'Em revisão',
  devolvido: 'Devolvido',
  publicado: 'Publicado',
  cancelado: 'Cancelado',
  pendente: 'Aguardando revisão',
  sem_lancamento: 'Sem lançamento',
};

export const CLASSE_STATUS = {
  rascunho: 'badge-neutral',
  enviado: 'badge-pending',
  em_revisao: 'badge-pending',
  pendente: 'badge-pending',
  devolvido: 'badge-warn',
  publicado: 'badge-ok',
  cancelado: 'badge-neutral',
  sem_lancamento: 'badge-neutral',
};

export const formatarNota = (n) =>
  n === null || n === undefined || n === '' ? '—' : Number(n).toFixed(1).replace('.', ',');

export const formatarDataHora = (iso) =>
  iso
    ? new Date(iso).toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';

export const formatarDataCurta = (iso) => (iso ? new Date(iso).toLocaleDateString('pt-BR') : '');

// Hoje: só a hora; outros dias: dia/mês
export function formatarData(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toDateString() === new Date().toDateString()
    ? d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

export const primeiroNome = (nome) => String(nome || '').split(' ')[0];

// Respeita a preferência "reduzir movimento" do sistema
export const reduzirMovimento = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
