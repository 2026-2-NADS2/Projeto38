// AuthContext.jsx — quem está logado, disponível para todo o app.
//   const { usuario, entrar, sair } = useAuth();

import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, sessao } from '../api/cliente';
import { useToast } from './ToastContext';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [carregando, setCarregando] = useState(Boolean(sessao.token()));
  const navigate = useNavigate();
  const toast = useToast();

  // Ao abrir o site com um token salvo, confirma com a API se ele ainda vale
  useEffect(() => {
    if (!sessao.token()) return;
    let ativo = true;
    api
      .get('/auth/me')
      .then((u) => ativo && setUsuario(u))
      .catch((err) => {
        if (!ativo) return;
        if (err.status !== 401) {
          // Servidor fora do ar: usa os dados salvos para não travar a tela
          setUsuario(sessao.usuario());
          toast('Sem conexão com o servidor. Algumas informações podem estar desatualizadas.', 'erro');
        }
      })
      .finally(() => ativo && setCarregando(false));
    return () => {
      ativo = false;
    };
  }, [toast]);

  // Token expirado em qualquer requisição -> volta para o login
  useEffect(() => {
    const aoExpirar = () => {
      setUsuario(null);
      navigate('/login?sessao=expirada', { replace: true });
    };
    window.addEventListener('kfka:sessao-expirada', aoExpirar);
    return () => window.removeEventListener('kfka:sessao-expirada', aoExpirar);
  }, [navigate]);

  const entrar = useCallback((token, dadosUsuario, lembrar) => {
    sessao.salvar(token, dadosUsuario, lembrar);
    setUsuario(dadosUsuario);
  }, []);

  const sair = useCallback(() => {
    sessao.limpar();
    setUsuario(null);
    navigate('/login', { replace: true });
  }, [navigate]);

  return <AuthContext.Provider value={{ usuario, carregando, entrar, sair }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
