// LayoutApp.jsx — moldura das telas internas: barra lateral (desktop),
// barra superior com menu em gaveta (celular) e a área onde cada página aparece (<Outlet />).

import { useEffect, useRef, useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../contexto/AuthContext';
import { ROTULO_PERFIL } from '../util/formato';
import { Logo } from './Basicos';
import CookieBanner from './CookieBanner';

// Itens do menu e quem pode ver cada um
const MENU = [
  { para: '/painel', rotulo: '📊 Painel', perfis: ['admin', 'professor', 'responsavel'] },
  { para: '/notas', rotulo: '📝 Notas e Faltas', perfis: ['professor'] },
  { para: '/notas', rotulo: '📝 Boletim', perfis: ['responsavel'] },
  { para: '/revisao', rotulo: '✅ Revisão', perfis: ['admin'] },
  { para: '/comunicacao', rotulo: '💬 Comunicação', perfis: ['admin', 'professor', 'responsavel'] },
];

export default function LayoutApp() {
  const { usuario, sair } = useAuth();
  const [menuAberto, setMenuAberto] = useState(false);
  const location = useLocation();
  const botaoMenu = useRef(null);
  const primeiroLink = useRef(null);

  // Fecha o menu ao trocar de página
  useEffect(() => setMenuAberto(false), [location.pathname]);

  // Esc fecha o menu e devolve o foco ao botão
  useEffect(() => {
    if (!menuAberto) return undefined;
    primeiroLink.current?.focus({ preventScroll: true });
    const aoTeclar = (e) => {
      if (e.key === 'Escape') {
        setMenuAberto(false);
        botaoMenu.current?.focus();
      }
    };
    document.addEventListener('keydown', aoTeclar);
    return () => document.removeEventListener('keydown', aoTeclar);
  }, [menuAberto]);

  const itens = MENU.filter((m) => m.perfis.includes(usuario.perfil));

  return (
    <>
      <header className="mobile-bar">
        <Logo />
        <button
          ref={botaoMenu}
          type="button"
          className="botao-menu"
          aria-label={menuAberto ? 'Fechar menu' : 'Abrir menu'}
          aria-expanded={menuAberto}
          aria-controls="menu-lateral"
          onClick={() => setMenuAberto((v) => !v)}
        >
          {menuAberto ? '✕' : '☰'}
        </button>
      </header>

      <div className="app-shell">
        {/* Fundo escuro do menu no celular: fica DENTRO do .app-shell, na mesma camada
            do menu (z-index 30 < 40), senão cobriria os próprios links */}
        <div className={`menu-fundo${menuAberto ? ' visivel' : ''}`} onClick={() => setMenuAberto(false)} />

        <aside className={`sidebar${menuAberto ? ' aberta' : ''}`} id="menu-lateral">
          <Logo />
          <nav className="sidebar-nav" aria-label="Menu principal">
            {itens.map((m, i) => (
              <NavLink key={m.rotulo} to={m.para} ref={i === 0 ? primeiroLink : undefined}
                className={({ isActive }) => (isActive ? 'active' : undefined)}>
                {m.rotulo}
              </NavLink>
            ))}
          </nav>
          <div className="sidebar-user">
            Logado como
            <br />
            <strong>{usuario.nome}</strong>
            <br />
            <small>{ROTULO_PERFIL[usuario.perfil]}</small>
            <br />
            <button type="button" className="link-botao" onClick={sair}>
              Sair
            </button>
          </div>
        </aside>

        <main className="app-main" id="conteudo">
          <Outlet />
        </main>
      </div>

      <CookieBanner />
    </>
  );
}
