// App.jsx — mapa de rotas do site (React Router).
//
//   Públicas:   /  /login  /cadastro  /privacidade
//   Internas:   /painel  /notas  /revisao  /comunicacao   (exigem login; algumas, perfil)
//   Qualquer outro endereço: página "não encontrada" (404)

import { Navigate, Route, Routes } from 'react-router-dom';
import LayoutApp from './componentes/LayoutApp';
import RotaProtegida from './componentes/RotaProtegida';
import Inicio from './paginas/Inicio';
import Login from './paginas/Login';
import Cadastro from './paginas/Cadastro';
import Privacidade from './paginas/Privacidade';
import Painel from './paginas/Painel';
import NotasFaltas from './paginas/NotasFaltas';
import Revisao from './paginas/Revisao';
import Comunicacao from './paginas/Comunicacao';
import NaoEncontrada from './paginas/NaoEncontrada';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Inicio />} />
      <Route path="/login" element={<Login />} />
      <Route path="/cadastro" element={<Cadastro />} />
      <Route path="/privacidade" element={<Privacidade />} />

      {/* Telas internas: mesma moldura (menu lateral) e login obrigatório */}
      <Route
        element={
          <RotaProtegida>
            <LayoutApp />
          </RotaProtegida>
        }
      >
        <Route path="/painel" element={<Painel />} />
        <Route
          path="/notas"
          element={
            <RotaProtegida perfis={['professor', 'responsavel']}>
              <NotasFaltas />
            </RotaProtegida>
          }
        />
        <Route
          path="/revisao"
          element={
            <RotaProtegida perfis={['admin']}>
              <Revisao />
            </RotaProtegida>
          }
        />
        <Route path="/comunicacao" element={<Comunicacao />} />
      </Route>

      {/* Endereços da versão HTML antiga continuam funcionando */}
      <Route path="/index.html" element={<Navigate to="/" replace />} />
      <Route path="/login.html" element={<Navigate to="/login" replace />} />
      <Route path="/dashboard.html" element={<Navigate to="/painel" replace />} />

      <Route path="*" element={<NaoEncontrada />} />
    </Routes>
  );
}
