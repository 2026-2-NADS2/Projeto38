// main.jsx — ponto de entrada do React.

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';

import './estilos/style.css';
import './estilos/components.css';
import './estilos/app.css';
import './estilos/background.css';
import './estilos/cookie-banner.css';
import './estilos/react.css';

import App from './App';
import { AuthProvider } from './contexto/AuthContext';
import { ToastProvider } from './contexto/ToastContext';

createRoot(document.getElementById('raiz')).render(
  <StrictMode>
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <App />
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  </StrictMode>
);
