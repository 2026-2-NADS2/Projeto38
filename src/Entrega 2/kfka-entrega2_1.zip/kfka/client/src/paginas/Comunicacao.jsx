// Comunicacao.jsx — conversas entre usuários, com atualização a cada 15 s.
// No celular, a lista e a conversa se alternam (botão ← volta para a lista).

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { api } from '../api/cliente';
import { useTitulo } from '../componentes/Basicos';
import { Carregando, ErroEstado, Vazio } from '../componentes/Estado';
import { useAuth } from '../contexto/AuthContext';
import { useToast } from '../contexto/ToastContext';
import { ROTULO_PERFIL, formatarData } from '../util/formato';

const descricao = (c) => (c.perfil === 'responsavel' && c.alunos ? `Resp. de ${c.alunos}` : ROTULO_PERFIL[c.perfil] || '');

function Bolha({ m }) {
  return (
    <div className={`msg${m.minha ? ' mine' : ''}`}>
      <span className="msg-texto">{m.texto}</span>
      <time className="msg-hora" dateTime={m.criado_em}>{formatarData(m.criado_em)}</time>
    </div>
  );
}

function Conversa({ contatoId, onVoltar, onMudou }) {
  const [dados, setDados] = useState(null); // { contato, mensagens }
  const [erro, setErro] = useState(null);
  const [texto, setTexto] = useState('');
  const [erroEnvio, setErroEnvio] = useState('');
  const [enviando, setEnviando] = useState(false);
  const area = useRef(null);
  const campo = useRef(null);

  const carregar = useCallback(
    async (silencioso = false) => {
      if (!silencioso) {
        setErro(null);
        setDados(null);
      }
      try {
        const novo = await api.get(`/mensagens/${contatoId}`);
        setDados((antigo) => (antigo && antigo.mensagens.length === novo.mensagens.length ? antigo : novo));
        if (!silencioso) onMudou();
      } catch (err) {
        if (!silencioso) setErro(err.message);
      }
    },
    [contatoId, onMudou]
  );

  useEffect(() => {
    carregar();
    // Atualiza a cada 15 s, só com a aba visível
    const id = setInterval(() => !document.hidden && carregar(true), 15000);
    return () => clearInterval(id);
  }, [carregar]);

  // Rola para a última mensagem sempre que a lista muda
  useLayoutEffect(() => {
    if (area.current) area.current.scrollTop = area.current.scrollHeight;
  }, [dados]);

  useEffect(() => {
    if (dados) campo.current?.focus();
  }, [dados?.contato?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  async function enviar(e) {
    e.preventDefault();
    const conteudo = texto.trim();
    if (!conteudo) return setErroEnvio('Escreva uma mensagem antes de enviar.');
    if (conteudo.length > 2000) return setErroEnvio('A mensagem deve ter no máximo 2000 caracteres.');
    setEnviando(true);
    try {
      const msg = await api.post('/mensagens', { destinatario_id: contatoId, texto: conteudo });
      setDados((d) => ({ ...d, mensagens: [...d.mensagens, msg] }));
      setTexto('');
      onMudou();
    } catch (err) {
      setErroEnvio(err.message);
    } finally {
      setEnviando(false);
    }
  }

  if (erro) return <ErroEstado mensagem={erro} onTentarNovamente={() => carregar()} />;
  if (!dados) return <Carregando texto="Carregando mensagens..." />;

  return (
    <>
      <header className="chat-topo">
        <button type="button" className="btn btn-ghost btn-sm voltar" aria-label="Voltar para conversas" onClick={onVoltar}>
          ←
        </button>
        <div>
          <strong>{dados.contato.nome}</strong>
          <small className="texto-secundario">{ROTULO_PERFIL[dados.contato.perfil]}</small>
        </div>
      </header>
      <div className="chat-mensagens" ref={area}>
        {dados.mensagens.length ? dados.mensagens.map((m) => <Bolha key={m.id} m={m} />) : <p className="chat-vazio">Nenhuma mensagem ainda. Diga olá!</p>}
      </div>
      <form className="chat-form" onSubmit={enviar} noValidate>
        <label className="sr-only" htmlFor="chat-texto">Mensagem</label>
        <textarea
          id="chat-texto"
          ref={campo}
          rows={1}
          maxLength={2000}
          placeholder="Escreva uma mensagem..."
          value={texto}
          onChange={(e) => {
            setTexto(e.target.value);
            setErroEnvio('');
          }}
          // Enter envia; Shift+Enter quebra linha
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              e.currentTarget.form.requestSubmit();
            }
          }}
        />
        <button type="submit" className="btn btn-primary" disabled={enviando}>
          Enviar
        </button>
      </form>
      <small className="campo-erro" role="alert">{erroEnvio}</small>
    </>
  );
}

export default function Comunicacao() {
  useTitulo('Comunicação');
  const { usuario } = useAuth();
  const toast = useToast();
  const [conversas, setConversas] = useState(null);
  const [contatos, setContatos] = useState([]);
  const [erro, setErro] = useState(null);
  const [aberta, setAberta] = useState(null); // id do contato

  const carregarLista = useCallback(async (silencioso = false) => {
    if (!silencioso) setErro(null);
    try {
      setConversas(await api.get('/mensagens/conversas'));
    } catch (err) {
      if (!silencioso) setErro(err.message);
    }
  }, []);

  useEffect(() => {
    carregarLista();
    api.get('/usuarios/contatos').then(setContatos).catch(() => setContatos([]));
    const id = setInterval(() => !document.hidden && carregarLista(true), 15000);
    return () => clearInterval(id);
  }, [carregarLista]);

  useEffect(() => {
    if (usuario.perfil === 'responsavel' && conversas && !conversas.length) {
      toast('Escolha a coordenação ou um professor em “+ Nova conversa”.');
    }
  }, [conversas, usuario.perfil, toast]);

  const atualizarLista = useCallback(() => carregarLista(true), [carregarLista]);

  let lista;
  if (erro) lista = <ErroEstado mensagem={erro} onTentarNovamente={() => carregarLista()} />;
  else if (!conversas) lista = <Carregando texto="Carregando conversas..." />;
  else if (!conversas.length) lista = <Vazio>Nenhuma conversa ainda. Use “+ Nova conversa” para começar.</Vazio>;
  else {
    lista = conversas.map((c) => (
      <button key={c.contato_id} type="button" className={`chat-item${c.contato_id === aberta ? ' active' : ''}`}
        onClick={() => setAberta(c.contato_id)}>
        <span className="chat-item-topo">
          <span className="nome">{c.nome}</span>
          <span className="hora">{formatarData(c.ultima_em)}</span>
        </span>
        <span className="sub">{descricao(c)}</span>
        <span className="preview">
          {c.enviada_por_mim ? 'Você: ' : ''}
          {c.ultima_mensagem}
        </span>
        {c.nao_lidas > 0 && (
          <span className="contador" aria-label={`${c.nao_lidas} não lida(s)`}>{c.nao_lidas}</span>
        )}
      </button>
    ));
  }

  return (
    <>
      <div className="app-topbar">
        <div>
          <h1>Comunicação</h1>
          <p>Converse diretamente com responsáveis, professores e a coordenação.</p>
        </div>
        <div className="filtros">
          <label className="sr-only" htmlFor="novo-contato">Nova conversa</label>
          <select id="novo-contato" className="select" value="" disabled={!contatos.length}
            onChange={(e) => e.target.value && setAberta(Number(e.target.value))}>
            <option value="">+ Nova conversa...</option>
            {contatos.map((c) => (
              <option key={c.id} value={c.id}>{`${c.nome} (${ROTULO_PERFIL[c.perfil]})`}</option>
            ))}
          </select>
        </div>
      </div>

      <div className={`chat-shell${aberta ? ' conversa-aberta' : ''}`}>
        <div className="chat-list" aria-label="Conversas">{lista}</div>
        <section className="chat-window" aria-live="polite">
          {aberta ? (
            <Conversa key={aberta} contatoId={aberta} onMudou={atualizarLista}
              onVoltar={() => { setAberta(null); atualizarLista(); }} />
          ) : (
            <p className="chat-vazio">Selecione uma conversa ao lado.</p>
          )}
        </section>
      </div>
    </>
  );
}
