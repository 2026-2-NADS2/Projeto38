// Revisao.jsx — a coordenação publica, devolve ou retifica os lançamentos.
// Publicar faz ENVIADO -> EM_REVISAO -> PUBLICADO (exigência dos triggers do banco).

import { useCallback, useEffect, useState } from 'react';
import { api } from '../api/cliente';
import { BadgeStatus, ChipsTags, useTitulo } from '../componentes/Basicos';
import BotaoAcao from '../componentes/BotaoAcao';
import Dialogo from '../componentes/Dialogo';
import { Carregando, ErroEstado, Vazio } from '../componentes/Estado';
import HistoricoDialogo from '../componentes/HistoricoDialogo';
import { useToast } from '../contexto/ToastContext';
import { formatarDataHora, formatarNota, reduzirMovimento } from '../util/formato';

const VAZIO = {
  pendentes: 'Nenhum lançamento aguardando revisão. 🎉',
  devolvidos: 'Nenhum lançamento devolvido aos professores.',
  publicados: 'Nenhum lançamento publicado ainda.',
};

const aguardando = (h) => (h === null ? '—' : h < 1 ? 'menos de 1 h' : h < 48 ? `${h} h` : `${Math.floor(h / 24)} dias`);

function CartaoRevisao({ ac, filtro, saindo, onPublicar, onMotivo, onHistorico }) {
  return (
    <article className={`cartao${saindo ? ' cartao-saindo' : ''}`}>
      <header className="cartao-topo">
        <div>
          <h2 className="cartao-titulo">{ac.aluno}</h2>
          <p className="texto-secundario">
            {ac.turma} · {ac.disciplina} · {ac.bimestre}º bimestre · versão {ac.versao}
          </p>
        </div>
        <BadgeStatus status={ac.status} />
      </header>

      <dl className="metricas">
        <div>
          <dt>Média</dt>
          <dd className={Number(ac.media) < 6 ? 'nota-baixa' : undefined}>{formatarNota(ac.media)}</dd>
        </div>
        <div>
          <dt>Faltas</dt>
          <dd>{ac.faltas}</dd>
        </div>
        <div>
          <dt>Professor</dt>
          <dd>{ac.professor}</dd>
        </div>
        {filtro === 'pendentes' && (
          <div>
            <dt>Aguardando</dt>
            <dd>{aguardando(ac.horas_aguardando)}</dd>
          </div>
        )}
        {filtro === 'publicados' && (
          <div>
            <dt>Publicado em</dt>
            <dd>{formatarDataHora(ac.publicado_em)}</dd>
          </div>
        )}
      </dl>

      <p className="parecer">{ac.descricao}</p>
      <ChipsTags nomes={ac.tags} />
      {ac.motivo_devolucao && <p className="motivo-box">↩ {ac.motivo_devolucao}</p>}

      <footer className="cartao-acoes">
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => onHistorico(ac.id)}>
          Histórico
        </button>
        {filtro === 'pendentes' && (
          <>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => onMotivo('devolver', ac)}>
              Devolver
            </button>
            <BotaoAcao className="btn btn-primary btn-sm" data-validar textoOcupado="Publicando..." onAcao={() => onPublicar(ac)}>
              Publicar
            </BotaoAcao>
          </>
        )}
        {filtro === 'publicados' && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => onMotivo('retificar', ac)}>
            Retificar
          </button>
        )}
      </footer>
    </article>
  );
}

export default function Revisao() {
  useTitulo('Revisão');
  const toast = useToast();
  const [filtro, setFiltro] = useState('pendentes');
  const [itens, setItens] = useState(null);
  const [erro, setErro] = useState(null);
  const [saindo, setSaindo] = useState(() => new Set());
  const [historicoId, setHistoricoId] = useState(null);
  // Diálogo de motivo (devolver / retificar)
  const [acao, setAcao] = useState(null); // { tipo, ac }
  const [motivo, setMotivo] = useState('');
  const [erroMotivo, setErroMotivo] = useState('');
  const [enviando, setEnviando] = useState(false);

  const carregar = useCallback(async () => {
    setErro(null);
    setItens(null);
    setSaindo(new Set()); // nova lista: nenhum cartão em saída
    try {
      setItens(await api.get(`/acompanhamentos/fila?status=${filtro}`));
    } catch (err) {
      setErro(err.message);
    }
  }, [filtro]);

  useEffect(() => {
    carregar();
  }, [carregar]);

  // O cartão revisado sai da lista com um fade curto (150 ms), sem recarregar tudo
  function remover(id) {
    setSaindo((s) => new Set(s).add(id));
    setTimeout(() => {
      setItens((lista) => lista?.filter((a) => a.id !== id) ?? lista);
      setSaindo((s) => {
        const novo = new Set(s);
        novo.delete(id);
        return novo;
      });
    }, reduzirMovimento() ? 0 : 150);
  }

  async function publicar(ac) {
    try {
      await api.patch(`/acompanhamentos/${ac.id}/publicar`);
      toast('Publicado: a família já pode ver.');
      remover(ac.id);
    } catch (err) {
      toast(err.message, 'erro');
      throw err;
    }
  }

  function abrirMotivo(tipo, ac) {
    setAcao({ tipo, ac });
    setMotivo('');
    setErroMotivo('');
  }

  async function confirmarMotivo(e) {
    e.preventDefault();
    const texto = motivo.trim();
    if (texto.length < 5) {
      setErroMotivo('Explique o motivo com pelo menos 5 caracteres.');
      return;
    }
    setEnviando(true);
    try {
      await api.patch(`/acompanhamentos/${acao.ac.id}/${acao.tipo}`, { motivo: texto });
      toast(acao.tipo === 'retificar' ? 'Publicação retificada: voltou para revisão.' : 'Devolvido ao professor.');
      remover(acao.ac.id);
      setAcao(null);
    } catch (err) {
      setErroMotivo(err.message);
    } finally {
      setEnviando(false);
    }
  }

  const retificar = acao?.tipo === 'retificar';

  let conteudo;
  if (erro) conteudo = <ErroEstado mensagem={erro} onTentarNovamente={carregar} />;
  else if (!itens) conteudo = <Carregando texto="Carregando lançamentos..." />;
  else if (!itens.length) conteudo = <Vazio>{VAZIO[filtro]}</Vazio>;
  else {
    conteudo = itens.map((ac) => (
      <CartaoRevisao key={ac.id} ac={ac} filtro={filtro} saindo={saindo.has(ac.id)} onPublicar={publicar}
        onMotivo={abrirMotivo} onHistorico={setHistoricoId} />
    ));
  }

  return (
    <>
      <div className="app-topbar">
        <div>
          <h1>Revisão de lançamentos</h1>
          <p>Confira o que os professores enviaram antes de publicar para as famílias.</p>
        </div>
        <div className="filtros">
          <label className="sr-only" htmlFor="filtro-status">Mostrar</label>
          <select id="filtro-status" className="select" value={filtro} onChange={(e) => setFiltro(e.target.value)}>
            <option value="pendentes">Aguardando revisão</option>
            <option value="devolvidos">Devolvidos ao professor</option>
            <option value="publicados">Publicados</option>
          </select>
        </div>
      </div>

      <div className="lista-cartoes" aria-live="polite">{conteudo}</div>

      <Dialogo aberto={Boolean(acao)} onFechar={() => setAcao(null)} rotuloId="motivo-titulo">
        <form onSubmit={confirmarMotivo} noValidate>
          <h2 id="motivo-titulo">{retificar ? 'Retificar publicação' : 'Devolver ao professor'}</h2>
          <p className="texto-secundario">
            {acao && `${acao.ac.aluno} — ${acao.ac.disciplina}, ${acao.ac.bimestre}º bimestre`}
            {retificar && '. O registro sai do boletim da família e volta para revisão.'}
          </p>
          <div className="field">
            <label htmlFor="motivo">{retificar ? 'Motivo da retificação' : 'Motivo da devolução'}</label>
            <textarea id="motivo" rows={3} maxLength={500} placeholder="Ex.: conferir o número de faltas." value={motivo}
              onChange={(e) => { setMotivo(e.target.value); setErroMotivo(''); }} />
            <small className="campo-erro" role="alert">{erroMotivo}</small>
          </div>
          <div className="dialogo-acoes">
            <button type="button" className="btn btn-ghost" onClick={() => setAcao(null)}>Cancelar</button>
            <button type="submit" className="btn btn-primary" disabled={enviando}>
              <span className="rotulo">{enviando ? 'Salvando...' : retificar ? 'Retificar' : 'Devolver'}</span>
            </button>
          </div>
        </form>
      </Dialogo>

      <HistoricoDialogo id={historicoId} onFechar={() => setHistoricoId(null)} />
    </>
  );
}
