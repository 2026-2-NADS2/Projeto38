// NotasFaltas.jsx — a mesma rota (/notas) mostra telas diferentes por perfil:
//   professor   -> lançamentos (média, faltas, parecer e tags)
//   responsável -> boletim publicado de cada filho

import { useTitulo } from '../componentes/Basicos';
import { useAuth } from '../contexto/AuthContext';
import Boletim from './notas/Boletim';
import Lancamentos from './notas/Lancamentos';

export default function NotasFaltas() {
  const { usuario } = useAuth();
  const ehResponsavel = usuario.perfil === 'responsavel';
  useTitulo(ehResponsavel ? 'Boletim' : 'Notas e Faltas');
  return ehResponsavel ? <Boletim /> : <Lancamentos />;
}
