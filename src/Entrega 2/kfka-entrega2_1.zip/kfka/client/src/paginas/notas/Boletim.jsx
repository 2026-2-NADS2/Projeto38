// Boletim.jsx — o responsável vê o que foi PUBLICADO de cada filho, por bimestre e disciplina,
// e confirma ciência (com retorno opcional para a escola).

import { useCallback, useEffect, useState } from 'react';
import { api } from '../../api/cliente';
import { ChipsTags } from '../../componentes/Basicos';
import Dialogo from '../../componentes/Dialogo';
import { Carregando, ErroEstado, Vazio } from '../../componentes/Estado';
import { useToast } from '../../contexto/ToastContext';
import { formatarDataCurta, formatarNota } from '../../util/formato';

function Ciencia({ d, onConfirmar }) {
  if (!d.data_ciencia) {
    return (
      <button type="button" className="btn btn-primary btn-sm nao-imprimir" onClick={() => onConfirmar(d)}>
        Confirmar ciência
      </button>
    );
  }
  return (
    <>
      <span className="badge badge-ok">✓ Ciente em {formatarDataCurta(d.data_ciencia)}</span>
      {d.retorno_responsavel && <p className="retorno">“{d.retorno_responsavel}”</p>}
    </>
  );
}

function BoletimFilho({ filho, realce, onConfirmar }) {
  const r = filho.resumo;
  return (
    <section className="boletim">
      <header className="boletim-topo">
        <div>
          <h2>{filho.nome}</h2>
          <p className="texto-secundario">
            {filho.turma || 'Sem turma'} · Matrícula {filho.matricula} · Média {formatarNota(r.media)} · {r.faltas_total} falta(s)
            {r.aguardando_ciencia > 0 && (
              <>
                {' · '}
                <strong className="destaque">{r.aguardando_ciencia} aguardando sua ciência</strong>
              </>
            )}
          </p>
        </div>
        <button type="button" className="btn btn-ghost btn-sm nao-imprimir" onClick={() => window.print()}>
          Imprimir / salvar PDF
        </button>
      </header>

      {!filho.bimestres.length && <p className="estado">Nenhum relatório publicado ainda para este aluno.</p>}

      {filho.bimestres.map((b) => (
        <div key={b.numero}>
          <h3 className="bimestre-titulo">{b.numero}º bimestre</h3>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th scope="col">Disciplina</th>
                  <th scope="col">Média</th>
                  <th scope="col">Faltas</th>
                  <th scope="col">Parecer do professor</th>
                  <th scope="col">Ciência</th>
                </tr>
              </thead>
              <tbody>
                {b.disciplinas.map((d) => (
                  <tr key={d.id}>
                    <td data-rotulo="Disciplina">
                      <strong>{d.disciplina}</strong>
                      <br />
                      <small className="texto-secundario">{d.professor}</small>
                    </td>
                    <td data-rotulo="Média">
                      <strong className={Number(d.media) < 6 ? 'nota-baixa' : undefined}>{formatarNota(d.media)}</strong>
                    </td>
                    <td data-rotulo="Faltas">{d.faltas}</td>
                    <td data-rotulo="Parecer" className="celula-parecer">
                      {d.descricao}
                      <ChipsTags nomes={d.tags} />
                    </td>
                    <td data-rotulo="Ciência" className={`celula-ciencia${realce === d.id ? ' realce' : ''}`}>
                      <Ciencia d={d} onConfirmar={onConfirmar} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </section>
  );
}

export default function Boletim() {
  const toast = useToast();
  const [filhos, setFilhos] = useState(null);
  const [erro, setErro] = useState(null);
  const [pendente, setPendente] = useState(null); // registro aguardando confirmação no diálogo
  const [retorno, setRetorno] = useState('');
  const [erroCiencia, setErroCiencia] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [realce, setRealce] = useState(null);

  const carregar = useCallback(async () => {
    setErro(null);
    setFilhos(null);
    try {
      setFilhos(await api.get('/boletim'));
    } catch (err) {
      setErro(err.message);
    }
  }, []);

  useEffect(() => {
    carregar();
  }, [carregar]);

  function abrir(d) {
    setPendente(d);
    setRetorno('');
    setErroCiencia('');
  }

  async function confirmar(e) {
    e.preventDefault();
    if (retorno.trim().length > 1000) {
      setErroCiencia('O retorno deve ter no máximo 1000 caracteres.');
      return;
    }
    setEnviando(true);
    try {
      const salvo = await api.post(`/acompanhamentos/${pendente.id}/ciencia`, retorno.trim() ? { observacao: retorno.trim() } : {});
      // Atualiza só a linha confirmada e o contador do filho
      setFilhos((lista) =>
        lista.map((f) => {
          let mudou = false;
          const bimestres = f.bimestres.map((b) => ({
            ...b,
            disciplinas: b.disciplinas.map((d) => {
              if (d.id !== pendente.id) return d;
              mudou = true;
              return { ...d, data_ciencia: salvo.data_ciencia, retorno_responsavel: salvo.observacao };
            }),
          }));
          return mudou ? { ...f, bimestres, resumo: { ...f.resumo, aguardando_ciencia: f.resumo.aguardando_ciencia - 1 } } : f;
        })
      );
      setRealce(pendente.id);
      setPendente(null);
      toast('Ciência confirmada. Obrigado!');
    } catch (err) {
      setErroCiencia(err.message);
    } finally {
      setEnviando(false);
    }
  }

  let conteudo;
  if (erro) conteudo = <ErroEstado mensagem={erro} onTentarNovamente={carregar} />;
  else if (!filhos) conteudo = <Carregando texto="Carregando boletim..." />;
  else if (!filhos.length) conteudo = <Vazio>Nenhum aluno vinculado à sua conta ainda. A coordenação fará o vínculo em breve.</Vazio>;
  else conteudo = filhos.map((f) => <BoletimFilho key={f.id} filho={f} realce={realce} onConfirmar={abrir} />);

  return (
    <>
      <div className="app-topbar">
        <div>
          <h1>Boletim</h1>
          <p>Médias, faltas e pareceres já revisados pela coordenação. Confirme a ciência de cada disciplina.</p>
        </div>
      </div>

      {conteudo}

      <Dialogo aberto={Boolean(pendente)} onFechar={() => setPendente(null)} rotuloId="ciencia-titulo">
        <form onSubmit={confirmar} noValidate>
          <h2 id="ciencia-titulo">Confirmar ciência</h2>
          <p className="texto-secundario">{pendente && `${pendente.disciplina} — ${pendente.bimestre}º bimestre`}</p>
          <div className="field">
            <label htmlFor="ciencia-retorno">Retorno para a escola (opcional)</label>
            <textarea id="ciencia-retorno" rows={3} maxLength={1000} placeholder="Ex.: Vamos incentivar a leitura em casa."
              value={retorno} onChange={(e) => { setRetorno(e.target.value); setErroCiencia(''); }} />
            <small className="campo-erro">{erroCiencia}</small>
          </div>
          <div className="dialogo-acoes">
            <button type="button" className="btn btn-ghost" onClick={() => setPendente(null)}>Cancelar</button>
            <button type="submit" className="btn btn-primary" disabled={enviando}>
              <span className="rotulo">{enviando ? 'Confirmando...' : 'Confirmar ciência'}</span>
            </button>
          </div>
        </form>
      </Dialogo>
    </>
  );
}
