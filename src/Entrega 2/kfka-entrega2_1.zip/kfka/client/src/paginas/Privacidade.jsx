// Privacidade.jsx — política de privacidade (LGPD): finalidade, dados coletados e direitos.

import { Link } from 'react-router-dom';
import { Logo, usePaginaPublica, useTitulo } from '../componentes/Basicos';

export default function Privacidade() {
  useTitulo('Política de Privacidade');
  usePaginaPublica();

  return (
    <main className="pagina-texto">
      <Link to="/">
        <Logo />
      </Link>
      <h1>Política de Privacidade</h1>
      <p>
        A KFKA trata dados pessoais apenas para o acompanhamento escolar dos alunos, seguindo a Lei Geral de Proteção
        de Dados (Lei nº 13.709/2018), com cuidado especial com os dados de crianças e adolescentes (art. 14).
      </p>

      <h2>Quais dados coletamos</h2>
      <ul>
        <li>Responsáveis: nome, e-mail, telefone (opcional) e a data do consentimento.</li>
        <li>Alunos: nome, matrícula, data de nascimento e turma — nada além do necessário.</li>
        <li>Acompanhamento: médias, faltas, pareceres, tags e a confirmação de ciência.</li>
        <li>Registros de acesso e de alterações (auditoria), para garantir a segurança e a rastreabilidade.</li>
      </ul>

      <h2>Para que usamos</h2>
      <p>
        Para que professores registrem o acompanhamento, a coordenação revise antes da publicação e os responsáveis
        acompanhem a vida escolar dos alunos. Os dados não são vendidos nem compartilhados com terceiros.
      </p>

      <h2>Quem pode ver</h2>
      <ul>
        <li>Responsáveis veem apenas os alunos vinculados a eles, e só o que já foi publicado.</li>
        <li>Professores veem apenas as turmas e disciplinas em que lecionam.</li>
        <li>A coordenação acessa os dados necessários à gestão escolar.</li>
      </ul>

      <h2>Segurança</h2>
      <p>
        Senhas são guardadas com criptografia (hash), o acesso é feito por sessão com prazo de expiração e cada
        alteração no acompanhamento fica registrada com autor e data.
      </p>

      <h2>Armazenamento no navegador</h2>
      <p>
        Usamos o armazenamento local do navegador apenas para manter sua sessão aberta e lembrar sua escolha sobre
        este aviso. Não usamos cookies de publicidade.
      </p>

      <h2>Seus direitos</h2>
      <p>
        Você pode pedir acesso, correção ou exclusão dos seus dados, ou revogar o consentimento, falando com a
        coordenação da escola.
      </p>

      <p style={{ marginTop: 'var(--space-lg)' }}>
        <Link to="/" className="btn btn-ghost">Voltar ao início</Link>
      </p>
    </main>
  );
}
