# KFKA — Plataforma de Acompanhamento Escolar

Plataforma web que centraliza o acompanhamento bimestral dos alunos (média, faltas, parecer descritivo e tags por disciplina), com **revisão pela coordenação antes da publicação** para as famílias e **auditoria automática** de cada alteração.

> Projeto Interdisciplinar — 2º ADS — Entrega 2 (back-end + integração com o front-end).

## Funcionalidades

| Perfil | O que faz |
| --- | --- |
| **Professor(a)** | Escolhe turma → disciplina → bimestre; lança média, faltas, parecer e tags; salva rascunho ou envia para revisão; vê o motivo quando algo é devolvido; consulta o histórico |
| **Coordenação (admin)** | Publica, devolve (com motivo) ou retifica lançamentos; vê o histórico completo; painel com indicadores por turma/disciplina e tags mais frequentes; cadastra alunos, turmas, usuários e vínculos |
| **Responsável** | Cria a própria conta (com aceite LGPD); vê o boletim **só do que foi publicado**; confirma ciência com retorno opcional para a escola; imprime/salva em PDF |
| Todos | Comunicação por mensagens (responsáveis só falam com a equipe) |

**Fluxo editorial** (garantido pelos triggers do banco):

```
RASCUNHO → ENVIADO → EM_REVISAO → PUBLICADO
              ↘           ↘
               DEVOLVIDO → ENVIADO ...        PUBLICADO → EM_REVISAO (retificação)
```

O professor só grava **dentro do período de digitação** do bimestre (tabela `bimestre`), e toda alteração vai para `historico_acompanhamento` com autor, data, antes/depois e observação.

## Tecnologias

- **Front-end:** React 19 + React Router (Vite), CSS3 responsivo, fetch assíncrono
- **Back-end:** Node.js + Express
- **Banco de dados:** MySQL 8 (`mysql2`) — script da equipe em `database/kfka_banco.sql` (tabelas, índices, triggers, views e carga)
- **Segurança:** senhas com `bcryptjs`, autenticação **JWT**, permissões por perfil, `helmet`, limite de tentativas de login, validação com **Zod**, consultas parametrizadas (contra SQL Injection), escape de HTML no front (contra XSS)

## Estrutura

```
kfka/
├── client/                      # FRONT-END (React + Vite)
│   ├── index.html
│   └── src/
│       ├── main.jsx             # ponto de entrada (Router + contextos)
│       ├── App.jsx              # mapa de rotas (inclui a página 404)
│       ├── api/cliente.js       # fetch para a API, sessão, erros padronizados
│       ├── contexto/            # AuthContext (usuário logado), ToastContext (avisos)
│       ├── componentes/         # LayoutApp (menu), RotaProtegida, Dialogo, BotaoAcao,
│       │                        # Estado (carregando/erro/vazio/esqueleto), HistoricoDialogo...
│       ├── paginas/             # Inicio, Login, Cadastro, Privacidade, Painel, NotasFaltas,
│       │   └── notas/           # Lancamentos + CartaoLancamento (professor), Boletim (responsável)
│       ├── util/formato.js      # rótulos e formatação
│       └── estilos/             # CSS (identidade visual da Entrega 1)
├── server/                      # BACK-END (Express)
│   ├── index.js / app.js        # inicia o servidor; entrega a API e o build do React
│   ├── config/env.js            # variáveis de ambiente
│   ├── db/                      # pool MySQL, transação com @usuario_id, setup do banco
│   ├── middlewares/             # auth (JWT/perfis), validar (Zod), erros padronizados
│   ├── routes/                  # auth, usuarios, escola, alunos, acompanhamentos, boletim, mensagens, dashboard
│   └── schemas/                 # regras de validação
├── database/kfka_banco.sql      # script MySQL da equipe (alterações do site marcadas com [SITE])
├── tests/api.test.js            # testes de integração da API
├── ROTEIRO-DE-TESTE.md
├── vite.config.mjs
├── .env.example
└── docker-compose.yml           # MySQL 8 local (opcional)
```

### Rotas do front-end

| Rota | Quem acessa | Tela |
| --- | --- | --- |
| `/` | todos | Página inicial |
| `/login`, `/cadastro`, `/privacidade` | todos | Entrar, criar conta de responsável, política de privacidade (LGPD) |
| `/painel` | logado | Painel (conteúdo muda por perfil) |
| `/notas` | professor, responsável | Lançamentos (professor) ou Boletim (responsável) |
| `/revisao` | coordenação | Fila de revisão |
| `/comunicacao` | logado | Mensagens |
| qualquer outra | todos | Página 404 do React |

Sem login, as telas internas mandam para `/login` (e voltam para a tela pedida depois de entrar). Perfil sem permissão volta para `/painel`.

## Como rodar localmente

Pré-requisitos: **Node.js 20+** e **MySQL 8** (Docker, MySQL instalado com Workbench, ou Railway).

```bash
# 1. Dependências
npm install

# 2. Variáveis de ambiente
cp .env.example .env
#   -> ajuste DATABASE_URL (usuário/senha do seu MySQL) e JWT_SECRET

# 3. MySQL (escolha um)
docker compose up -d          # MySQL 8 local; a DATABASE_URL do .env.example já funciona
#   ou use o MySQL instalado no computador (Workbench)

# 4. Banco: roda o database/kfka_banco.sql e grava as senhas de demonstração
npm run db:setup              # ATENÇÃO: apaga e recria o banco "kfka"

# 5. Desenvolvimento: dois terminais
npm run dev        # terminal 1 — API em http://localhost:3000
npm run dev:web    # terminal 2 — React em http://localhost:5173 (abra este no navegador)
```

Para testar como em produção (um servidor só):

```bash
npm run build      # gera client/dist
npm start          # front + API em http://localhost:3000
```

> **Preferem rodar o script pelo Workbench?** Pode: execute o `kfka_banco.sql` (raio ⚡) e depois rode só `npm run db:senhas`, que troca o marcador de senha pelo hash bcrypt real.

> **Abra pelo Vite (`http://localhost:5173`) no desenvolvimento ou pelo servidor (`http://localhost:3000`) depois do build.** Pelo Live Server ou abrindo o arquivo direto, o site não encontra a API.

### Usuários de demonstração (carga do kfka_banco.sql)

Senha de todos: valor de `SEED_SENHA` no `.env` (padrão: `Senha@123`).

| E-mail | Perfil | Observação |
| --- | --- | --- |
| admin@kfka.edu.br | Coordenação | Marina |
| carlos.menezes@kfka.edu.br | Professor | Língua Portuguesa e História |
| fernanda.lopes@kfka.edu.br | Professora | Matemática |
| ricardo.tanaka@kfka.edu.br | Professor | Ciências e Inglês |
| ana.ribeiro@email.com | Responsável | Mãe de Lucas e Beatriz |
| luciana.andrade@email.com | Responsável | Mãe de Gabriel, tia de Laura |
| marcos.oliveira@email.com | Responsável | Pai de Sofia, tio de Pedro |

> ⚠️ **Período de digitação:** pela carga do script, só o 4º bimestre está aberto (01/11 a 15/12/2026). Fora dessas datas o banco recusa lançamentos — ajuste `digitacao_inicio`/`digitacao_fim` na tabela `bimestre` antes da apresentação, se necessário.

### Testes

Os testes rodam o `db:setup` (**apagam e recriam o banco kfka**):

```bash
NODE_ENV=test npm test
```

## API

Base: `/api`. Sucesso: `{ "dados": ... }`. Erros sempre no formato:

```json
{ "erro": { "codigo": "DADOS_INVALIDOS", "mensagem": "Verifique os dados enviados.", "detalhes": [{ "campo": "media", "mensagem": "A média máxima é 10." }] } }
```

| Status | Código | Quando |
| --- | --- | --- |
| 400 | `REQUISICAO_INVALIDA` | JSON malformado, valor inválido |
| 401 | `NAO_AUTENTICADO` | sem token, token inválido/expirado, login incorreto |
| 403 | `SEM_PERMISSAO` / `CONTA_DESATIVADA` | perfil sem acesso; professor fora da sua turma/disciplina; usuário inativo |
| 404 | `NAO_ENCONTRADO` / `ROTA_NAO_ENCONTRADA` | registro ou rota inexistente da API (páginas inexistentes do site mostram a 404 do React) |
| 409 | `CONFLITO` | e-mail/matrícula repetidos, registro já enviado/publicado, ciência já confirmada |
| 409 | `REGRA_DO_BANCO` | regra de trigger: fora do período de digitação, transição de status não permitida |
| 422 | `DADOS_INVALIDOS` | falha de validação (com `detalhes` por campo) |
| 429 | `MUITAS_TENTATIVAS` | excesso de tentativas de login/cadastro |
| 503 | `BANCO_INDISPONIVEL` / `SENHA_DEMO_NAO_CONFIGURADA` | MySQL fora do ar; faltou `npm run db:senhas` |
| 500 | `ERRO_INTERNO` | erro inesperado (detalhes só no log do servidor) |

Rotas protegidas exigem `Authorization: Bearer <token>`.

| Método | Rota | Acesso | Descrição |
| --- | --- | --- | --- |
| GET | `/api/saude` | público | status da API e do banco |
| POST | `/api/auth/cadastro` | público | cria responsável (`aceite_lgpd: true` obrigatório) |
| POST | `/api/auth/login` | público | login → token JWT |
| GET | `/api/auth/me` | logado | usuário logado |
| GET / POST | `/api/usuarios` | admin | lista / cria (professor exige `registro`) |
| GET | `/api/usuarios/contatos` | logado | com quem posso conversar |
| GET / POST | `/api/turmas` | logado / admin | turmas do ano (professor: só as dele) / cria |
| GET | `/api/disciplinas?turma_id=` | logado | disciplinas da turma (professor: só as dele) |
| GET | `/api/bimestres` | logado | bimestres e se a digitação está aberta |
| GET | `/api/tags` | logado | tags de desempenho |
| GET | `/api/alunos` | logado | lista por perfil (`?turma_id=` `?busca=`) |
| GET | `/api/alunos/:id` | logado | detalhe (+ responsáveis para a equipe) |
| POST / PUT / DELETE | `/api/alunos[/:id]` | admin | cria e matricula / edita / desativa |
| POST / DELETE | `/api/alunos/:id/responsaveis[/:rid]` | admin | vincula (por e-mail) / desvincula |
| GET | `/api/acompanhamentos?turma_id&disciplina_id&bimestre_id` | professor, admin | planilha da turma |
| PUT | `/api/acompanhamentos` | professor | salva rascunho ou envia (`enviar: true`) |
| POST | `/api/acompanhamentos/:id/enviar` | professor | rascunho/devolvido → enviado |
| GET | `/api/acompanhamentos/fila?status=` | admin, professor | `pendentes`, `devolvidos`, `publicados`, `rascunhos` |
| PATCH | `/api/acompanhamentos/:id/publicar` | admin | publica (passa por EM_REVISAO) |
| PATCH | `/api/acompanhamentos/:id/devolver` | admin | devolve com `{ motivo }` |
| PATCH | `/api/acompanhamentos/:id/retificar` | admin | publicado → em revisão, com `{ motivo }` |
| GET | `/api/acompanhamentos/:id/historico` | admin, professor | auditoria (triggers) |
| POST | `/api/acompanhamentos/:id/ciencia` | responsável | confirma ciência `{ observacao? }` |
| GET | `/api/boletim` | responsável | filhos + publicados por bimestre/disciplina (view) |
| GET | `/api/mensagens/conversas` | logado | conversas com última mensagem e não lidas |
| GET | `/api/mensagens/:usuarioId` | logado | histórico da conversa (marca como lidas) |
| POST | `/api/mensagens` | logado | envia `{ destinatario_id, texto }` |
| GET | `/api/dashboard/resumo` | logado | números, indicadores e tags (views) por perfil |

### Como o back-end conversa com os triggers

Os triggers precisam saber **quem** está alterando. Toda gravação em `acompanhamento` passa por `db.transacao(usuarioId, ...)`, que, na mesma conexão:

1. abre a transação e roda `SET @usuario_id = ?` (e `@observacao` quando há motivo);
2. executa os comandos — os triggers validam as regras e gravam o histórico;
3. faz commit (ou rollback em caso de erro) e **limpa** as variáveis antes de devolver a conexão ao pool.

## Deploy (front + back juntos)

O MySQL precisa aceitar **triggers**. O mais simples é o **Railway** (acesso root):

1. **Railway → New → Database → MySQL.** Em *Connect*, copie host, porta, usuário e senha.
2. Monte `DATABASE_URL=mysql://root:SENHA@HOST:PORTA/kfka` (o script cria o banco `kfka`).
3. Rode o banco a partir do seu computador, apontando para o Railway: `npm run db:setup`.
4. **Web Service** (Railway ou Render) a partir do repositório GitHub:
   - Build: `npm install --include=dev && npm run build` — Start: `npm start` — Health check: `/api/saude`
   - (`--include=dev` garante que o Vite seja instalado mesmo com `NODE_ENV=production`)
   - Variáveis: `NODE_ENV=production`, `DATABASE_URL`, `JWT_SECRET` (32+ caracteres), `SEED_SENHA`, `DB_TIMEZONE=-03:00`
5. Em produção, o `db:setup` só roda com `--forcar` (ele apaga o banco).

> Se o provedor recusar criar trigger com o erro *"You do not have the SUPER privilege and binary logging is enabled"*, ative `log_bin_trust_function_creators = 1` no painel do MySQL.

## Trabalho em equipe (histórico de commits)

O critério pede commits de **todos os integrantes**. Sugestão de divisão:

- Banco (`database/kfka_banco.sql`, `server/db/`)
- Autenticação e middlewares (`server/middlewares/`, `routes/auth.routes.js`, `routes/usuarios.routes.js`)
- Lançamento e revisão (`routes/acompanhamentos.routes.js`)
- Boletim, painel e comunicação (`routes/boletim.routes.js`, `routes/dashboard.routes.js`, `routes/mensagens.routes.js`)
- Front React: estrutura, rotas e componentes (`client/src/App.jsx`, `componentes/`, `contexto/`)
- Telas React (`client/src/paginas/`)
- Testes e deploy (`tests/`, README)
