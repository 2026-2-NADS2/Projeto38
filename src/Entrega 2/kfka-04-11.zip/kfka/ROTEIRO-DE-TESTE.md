# Roteiro de teste — KFKA com MySQL

Use este roteiro na primeira execução com o MySQL de vocês e como ensaio da apresentação.
Marque cada item. Se algo falhar, anote a mensagem do terminal e da tela.

## 0. Preparação

- [ ] `npm install` terminou sem erros
- [ ] `.env` criado a partir do `.env.example`, com `DB_USER`/`DB_PASSWORD` do seu MySQL (ou `DATABASE_URL`)
- [ ] `npm run db:setup` mostrou **"Script executado (81 comandos)"** e **"Senha de demonstração gravada em 8 usuário(s)"**
- [ ] No Workbench: `SHOW TRIGGERS FROM kfka;` lista 4 triggers e `SHOW FULL TABLES IN kfka WHERE Table_type = 'VIEW';` lista 6 views
- [ ] `npm run dev` mostrou **"Servidor rodando em http://localhost:3000"**
- [ ] Em outro terminal, `npm run dev:web` abriu o React em **http://localhost:5173** (use este endereço no navegador)
- [ ] `npm run build` termina sem erros e, depois dele, `npm start` serve o site em http://localhost:3000
- [ ] http://localhost:3000/api/saude responde `"banco":"conectado"`
- [ ] A data de hoje está entre 01/11 e 15/12/2026 (se não, ajuste a tabela `bimestre`)

Senha de todos os usuários: `Senha@123`

## 1. Professor — lançamento (carlos.menezes@kfka.edu.br)

- [ ] O menu mostra Painel, Notas e Faltas e Comunicação (sem Revisão)
- [ ] Painel: cartões de rascunhos, devolvidos e aguardando, e a tabela de indicadores só com as disciplinas dele
- [ ] Notas e Faltas (/notas): escolha **6º A**, **Língua Portuguesa**, **4º bimestre** → aviso verde "Digitação do 4º bimestre aberta até 15/12/2026"
- [ ] Lucas aparece como **Rascunho** (veio da carga do script)
- [ ] No Gabriel, clique em "Enviar para revisão" sem preencher → aparece "Informe a média."
- [ ] Preencha média 6,5, faltas 2, um parecer e marque 2 tags → "Salvar rascunho" → status **Rascunho**
- [ ] "Enviar para revisão" → status **Enviado** e os campos ficam bloqueados
- [ ] "Histórico" mostra: criou como Rascunho → Rascunho → Enviado, com o nome do Carlos
- [ ] Troque para o **1º bimestre** → aviso amarelo "Digitação do 1º bimestre fechada" e nada editável

## 2. Coordenação — revisão (admin@kfka.edu.br)

- [ ] O menu mostra Revisão e não mostra Notas e Faltas
- [ ] Painel: indicadores por turma/disciplina (view `vw_indicadores_turma_disciplina`) e barras de tags (view `vw_frequencia_tags`)
- [ ] Revisão → "Aguardando revisão": aparecem o Pedro (Matemática) e o Gabriel (Língua Portuguesa)
- [ ] No Gabriel, "Devolver" sem motivo → erro; com o motivo "Conferir o número de faltas." → o cartão some da lista
- [ ] Filtro "Devolvidos" → Gabriel e Beatriz (a Beatriz já veio devolvida na carga)
- [ ] "Histórico" do Gabriel mostra a devolução com o motivo e o nome da Marina

## 3. Professor corrige → Coordenação publica

- [ ] (Carlos) O Gabriel mostra a caixa "Devolvido pela coordenação: Conferir o número de faltas."
- [ ] Mude faltas para 1 → "Enviar para revisão"
- [ ] (Marina) Revisão → Gabriel → "Publicar" → o cartão some e aparece "Publicado: a família já pode ver."
- [ ] O histórico mostra Devolvido → Enviado (Carlos), Enviado → Em revisão e Em revisão → Publicado (Marina), e "Faltas: 2 → 1"

## 4. Responsável — boletim (luciana.andrade@email.com)

- [ ] Painel: "Meus filhos" com Gabriel e Laura
- [ ] Boletim: Gabriel tem 1º bimestre (Língua Portuguesa e Matemática, com ciência já confirmada na carga) e o 4º bimestre com a nota publicada no passo 3
- [ ] "Confirmar ciência" → escreva um retorno → o botão vira "✓ Ciente em …" com o texto
- [ ] "Imprimir / salvar PDF" abre a impressão sem menu, botões ou banners
- [ ] (Marina) Revisão → Publicados → Gabriel → "Retificar" com motivo → (Luciana) o 4º bimestre some do boletim

## 5. Cadastro e segurança

- [ ] /cadastro sem marcar a LGPD → "É preciso aceitar para criar a conta."
- [ ] Cadastro completo → entra no painel com "Nenhum aluno vinculado…"
- [ ] No Workbench: `SELECT * FROM responsavel ORDER BY id DESC LIMIT 1;` mostra telefone e `aceite_lgpd_em` preenchidos
- [ ] Sem login, abrir /painel → volta para o login; depois de entrar, volta para a tela pedida
- [ ] Professor abrindo /revisao → volta para o painel
- [ ] /qualquer-coisa mostra a página 404 do React; /api/qualquer-coisa responde JSON 404
- [ ] Botões Voltar/Avançar do navegador funcionam entre as telas
- [ ] Link “Política de Privacidade” (cadastro e aviso de cookies) abre /privacidade

## 6. Comunicação

- [ ] (Carlos) A conversa com a Ana aparece como "Resp. de Beatriz Ribeiro, Lucas Ribeiro" com 1 mensagem não lida
- [ ] Enviar mensagem com Enter funciona; Shift+Enter quebra a linha
- [ ] (Ana) Em "+ Nova conversa" só aparecem a coordenação e os professores

## 7. Celular (DevTools → modo responsivo, ou celular na mesma rede)

- [ ] O menu ☰ abre a gaveta; tocar fora ou apertar Esc fecha
- [ ] Os cartões de lançamento ficam em uma coluna e os campos não dão zoom ao tocar (iPhone)
- [ ] No chat, a lista e a conversa se alternam com o botão ←

## Consultas úteis para mostrar na apresentação (Workbench)

```sql
SELECT * FROM vw_fila_revisao;
SELECT * FROM vw_relatorio_responsavel WHERE responsavel_id = 3;
SELECT acao, status_anterior, status_novo, faltas_anterior, faltas_nova, observacao, data_hora
  FROM historico_acompanhamento WHERE acompanhamento_id = (SELECT MAX(id) FROM acompanhamento)
 ORDER BY id;
```
